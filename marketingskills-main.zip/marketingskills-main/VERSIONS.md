# Marketing Skills Versions

Current versions of all skills. Agents can compare against local versions to check for updates.

| Skill | Version | Last Updated |
|-------|---------|--------------|
| ab-testing | 2.0.3 | 2026-10-27 |
| ad-creative | 2.12.2 | 2026-10-26 |
| ai-seo | 2.11.0 | 2026-10-26 |
| analytics | 2.2.2 | 2026-10-27 |
| aso | 2.0.3 | 2026-10-27 |
| attribution | 1.1.6 | 2026-10-19 |
| churn-prevention | 2.0.3 | 2026-10-12 |
| co-marketing | 2.0.3 | 2026-10-12 |
| cold-email | 2.2.1 | 2026-10-27 |
| community-marketing | 2.0.2 | 2026-10-27 |
| competitor-profiling | 2.1.4 | 2026-10-15 |
| competitors | 2.3.0 | 2026-10-01 |
| content-strategy | 2.1.5 | 2026-10-27 |
| conversion-tracking | 1.0.1 | 2026-10-19 |
| copy-editing | 2.2.1 | 2026-10-27 |
| copywriting | 2.3.2 | 2026-10-27 |
| cro | 2.0.3 | 2026-10-08 |
| customer-research | 2.0.5 | 2026-10-27 |
| directory-submissions | 2.1.4 | 2026-10-27 |
| emails | 2.1.4 | 2026-10-15 |
| events | 1.0.0 | 2026-08-23 |
| free-tools | 2.0.3 | 2026-10-15 |
| image | 2.0.3 | 2026-10-27 |
| influencer-marketing | 1.4.0 | 2026-10-15 |
| launch | 2.2.0 | 2026-10-07 |
| lead-magnets | 2.1.1 | 2026-10-27 |
| link-building | 1.0.1 | 2026-10-19 |
| marketing-council | 1.0.0 | 2026-07-06 |
| marketing-ideas | 2.0.1 | 2026-08-23 |
| marketing-loops | 1.6.2 | 2026-10-27 |
| marketing-plan | 1.2.2 | 2026-10-12 |
| marketing-psychology | 2.0.0 | 2026-05-05 |
| offers | 1.0.3 | 2026-10-27 |
| onboarding | 2.0.2 | 2026-10-12 |
| ads | 2.7.0 | 2026-10-26 |
| paywalls | 2.1.1 | 2026-10-27 |
| popups | 2.0.1 | 2026-10-27 |
| pricing | 2.1.4 | 2026-10-12 |
| product-marketing | 2.2.0 | 2026-10-15 |
| programmatic-seo | 2.1.1 | 2026-10-27 |
| prospecting | 1.5.0 | 2026-10-27 |
| public-relations | 1.2.1 | 2026-10-15 |
| referrals | 2.2.1 | 2026-10-12 |
| revops | 2.2.2 | 2026-10-27 |
| sales-enablement | 2.4.0 | 2026-10-07 |
| schema | 2.0.2 | 2026-10-08 |
| seo-audit | 2.2.2 | 2026-10-15 |
| signup | 2.0.1 | 2026-10-08 |
| site-architecture | 2.1.0 | 2026-10-06 |
| sms | 1.1.0 | 2026-10-02 |
| social | 2.4.0 | 2026-10-14 |
| video | 2.3.0 | 2026-10-26 |

## Recent Changes

### 2.13.9 (2026-10-27)

- **prospecting** (1.4.0 → 1.5.0): signal plays adds **gap plays**: a spend or growth signal paired with a gap you can verify from outside that your offer fixes (ads with no visible tracking, paid traffic sent to the homepage, long-running ad creative, thin location or integration pages, lead magnets with no follow-up, expansion without localization, hiring for repetitive work). Each row says how to check the gap. Rules: evidence required for every gap, limits of outside checks (server-side tracking, brand-search homepages, winning ads that run long), re-check within 7 days of sending, and open with the observation and a question. The signal-tools table adds X search and the public ad libraries. Prompted by Mitch Davey's post on signal plays.
- **marketing-loops** (1.6.1 → 1.6.2): the signal-sweep loop verifies and saves evidence for gap plays before staging a touch.

### 2.13.8 (2026-10-27)

- **Perplexity Computer ZIPs**: each release now includes `<name>-perplexity.zip` for every skill, with `SKILL.md` at the archive root as Perplexity requires (the source and Claude web ZIPs nest the skill in a folder, so Perplexity rejected them). The packager's new `perplexity` target keeps the original skill files and fails the build if a skill exceeds Perplexity's documented limits: 100 files, 20 MB unzipped, a 1,024-character description. Install steps are in the README (Option 9). No skill content changed.

### 2.13.7 (2026-10-27)

Fixes contradictions and stale facts found while rewriting marketing-skills.com's skill pages:

- **ab-testing** (2.0.2 → 2.0.3): sample-size tables recomputed. The reference ran about 2.3× high (31,000 per variant for 3% → 3.6%) and SKILL.md about 10–20% low (12k); both now come from the two-proportion formula at α 0.05 two-sided, 80% power (14k), with the assumptions stated.
- **cold-email** (2.2.0 → 2.2.1): follow-up reply share aligned with the sourced Instantly 2026 benchmark (~58% of replies from email 1, ~42% from follow-ups) instead of an unsourced 55%.
- **revops** (2.2.1 → 2.2.2): MQL thresholds tied to their own example point tables (the two references used different weights), and SLA recipes reassign leads only under an agreed reassignment rule, matching inbound-routing.
- **paywalls** (2.1.0 → 2.1.1) and **offers** (1.0.2 → 1.0.3): paywall discount experiments now reward commitment and real deadlines (offers rules out acquisition discounts and fake scarcity); fake countdowns join the dark-patterns list; annual-prepay pricing is distinguished from acquisition discounts.
- **image** (2.0.2 → 2.0.3): current Black Forest Labs names (FLUX 3 Image; FLUX.2 [pro]/[flex]/[dev]/[klein]; FLUX.1 Kontext as previous generation), Midjourney V7 throughout, and an unsourced "#1 page speed killer" line removed. OpenAI's gpt-image-2.5 names checked against its deprecations page.
- **directory-submissions** (2.1.3 → 2.1.4): G2's deal for Capterra, GetApp, and Software Advice dated to its Jan 2026 announcement, with Software Advice no longer called a Gartner property; "AI engines penalize duplicate content" (unsourced) replaced, eval updated; a dated G2 price removed.
- **aso** (2.0.2 → 2.0.3): the screenshot rubric weights the first three screens instead of rewarding 8–10 (benchmarks say returns diminish past 6); the +2.5pp CPP figure is labelled as the organic-referral lift, distinct from the +5.9% average.
- **analytics** (2.2.1 → 2.2.2): gtag samples send GA4's recommended `sign_up` event, mapped from the internal `signup_completed`.
- **programmatic-seo** (2.1.0 → 2.1.1): subfolder advice rests on internal links, not a claim that subdomains split authority (its platforms reference says Google ranks neither higher); "Stats" removed from the playbook table.
- **content-strategy** (2.1.4 → 2.1.5): the scoring example totals 7.9, not 8.0. **community-marketing** (2.0.1 → 2.0.2): "5 community models" described four. **copywriting** (2.3.1 → 2.3.2): clarity figures credited to Founding Marketing, Ch. 3. **customer-research** (2.0.4 → 2.0.5): one persona minimum. **copy-editing** (2.2.0 → 2.2.1): its approved example dropped an em dash its own check bans. **popups** (2.0.0 → 2.0.1) and **lead-magnets** (2.1.0 → 2.1.1): duplicate related-skill entries merged.

### 2.13.6 (2026-10-27)

- **Tools registry**: 22 tools now document official MCP servers that the registry and their integration guides listed as unavailable: Mixpanel, Amplitude, PostHog, Semrush, Ahrefs, Similarweb, Salesforce, Kit, Klaviyo, Brevo, ActiveCampaign, beehiiv, Optimizely, Customer.io, Typeform, Buffer, Livestorm, PartnerStack, Tolt, Twilio (beta), Attentive (beta), and Webflow. Each guide links the vendor's MCP docs with a checked date. Category-table notes that ranked tools ("Best for links", "Most popular", "Stripe is the default") now state facts instead. The MCP-enabled list in AGENTS.md is updated to match. No skill content changed.

### 2.13.5 (2026-10-26)

- **paywalls** (2.0.0 → 2.1.0): new `references/mobile-subscription-paywalls.md` for consumer iOS/Android subscription apps: the paywall after onboarding's first personalized result, hard paywall vs. freemium (RevenueCat 2026 data), yearly-first plan presentation, trials with reminders and trial length as a test, one abandon offer, dated store fees (Apple Small Business Program; Google Play's June 2026 10% + 5% split, with the 10% applying to web links; the US link-out commission still in court), the web-to-app funnel, revenue per download, and an App Store review checklist. New description triggers for mobile and subscription-app paywalls. Adapted from Blake Anderson's ai-app-playbook (MIT); his "best and cheapest" stack verdicts were left out.

### 2.13.4 (2026-10-26)

Learnings from a batch of October 2026 posts, verified before inclusion:

- **ads** (2.6.2 → 2.7.0): the Meta playbook adds **ad sequencing**: why order matters to Meta's ranking model, the narrow auction setup (Awareness or Engagement objective, target frequency, lifetime budget of 7+ days, 2+ ads), sizing a sequence to the flight, and the cost trade-off. The creative-research reference adds a **persistent competitor ad tracker** (weekly pulls from the Meta, Google and LinkedIn ad libraries, vision tagging, diffs, gap questions), with a caveat that ad longevity is a proxy, not proof. The Google Search playbook covers **AI Max** under the same gate as broad match. Sources: Cody Schneider, Jon Loomer, Meta Engineering.
- **ai-seo** (2.10.2 → 2.11.0): the prompt-portfolio reference adds scoring by **buying topic** and a fix-before-create sequence (Jam's AI search audit). Platform notes add Bing Webmaster Tools' **AI Performance report and grounding queries**, and Brave's submit-url page with its limits. Agent readiness adds Fern's Agent Score for developer docs.
- **prospecting** (1.3.0 → 1.4.0): signal plays adds **warm paths**: mining your own network (LinkedIn export, calendar, inbox), matching it to target accounts, paid connectors per vertical, and double opt-in intros (Cody Schneider's podcast with Super Connector).
- **video** (2.2.2 → 2.3.0): adds a **personalized video per account** workflow (component library, motion primitives, demo-flow menu, render engine, automated QA, tracker), adapted from Harvey's write-up. Drops the "recommended" label on HeyGen.
- **directory-submissions** (2.1.2 → 2.1.3): the Notion entry now reflects the Notion Marketplace's requirements (public connection with the "Any workspace" scope, which can't be changed later, plus a review that includes security).

Not incorporated: duplicating Shopping products to test images and landing pages (third-party sources call it a Shopping policy violation), agency spend anecdotes, and an unverified 50-site launch list.

### 2.13.3 (2026-10-26)

- **video** (2.2.1 → 2.2.2) and the **Hyperframes integration guide**: the Hyperframes vs Remotion comparison now sticks to facts that don't drift (HTML vs React authoring, and how each times animation) and points to each project's docs for rendering, licensing, and features. Removed the unsupported "more powerful than Hyperframes" line (flagged by a HyperFrames maintainer), the "recommended for agents" label, and the stale cloud-rendering, license-tier, and ecosystem rows.
- **ad-creative** (2.12.1 → 2.12.2): code-based video ads no longer call Remotion "the best option". The section, decision tree, cost table, and workflows now name code-based video (Remotion or Hyperframes), point to the `video` skill for choosing between them, and drop the stale license-tier pricing line. The video, image, and voice decision trees now list tools as "options include" by need instead of single picks or "best quality" rankings, and the cost table is marked as rough estimates to verify.

### 2.13.2 (2026-10-26)

- **ai-seo** (2.10.1 → 2.10.2): agent-readiness reference adds the AgentReady open standard (agentready.org, led by Ora): find → read → act ordering, MUST/SHOULD/MAY practice IDs to cite in audits, and Ora's study figures (3.7× more fact-free answers when agents can't read the site, 1.9× recommendation rate, 60% vs 37% pricing accuracy) labeled as vendor research. Adds WAF-as-separate-gate, 429 + Retry-After over challenge pages, linking discovery files, the AI Catalog, visible-text facts over JSON-LD-only, and the act tier (MCP server or CLI, finishable auth, OpenAPI). Markdown mirrors downgraded to MAY since format didn't change task success. robots.txt guidance (reference and SKILL.md) now defaults to a wildcard allow with named groups only for deliberate exceptions.

### 2.13.1 (2026-10-19)

- **conversion-tracking** (1.0.0 → 1.0.1): an ad-platform setup now reaches the delivery decision when the user mentions ad blockers, iOS or ATT signal loss, or conversions the platform is missing or under-reporting, and walks through the options in `references/server-side.md`, free and native paths first. A narrower version of the "every ad-platform setup reaches the delivery decision" change dropped from 2.13.0. Names no vendor.

### 2.13.0 (2026-10-19)

- Added the **`conversion-tracking`** skill (1.0.0). Setting up, auditing, verifying and fixing the path from a conversion on a website to Google Ads, Meta, GA4, LinkedIn, TikTok and Microsoft Ads, for lead generation and ecommerce. Gives an orphaned job a home. Analytics listed conversion tracking as a trigger without covering it, attribution routed pixels and CAPI to ads, and ads held one reference file. Built on one distinction, that lead gen has to infer success from a browser signal while ecommerce reads it from an order record. Nine references (how each form, booking and chat tool signals success, the complete browser-side path, the server-side options with prices, ecommerce platforms including Shopify's 26 Aug 2026 Additional Scripts removal, Google Ads, Meta, other platforms, the audit playbook, and why the numbers never match), 26 detection snippets (22 form and booking tools plus 4 universal patterns), importable GTM recipes merged by `scripts/build_recipe.py`, and 16 evals. Audit scoring follows the ads skill's audit guardrails, summarised inline. New skill = repo y release; total skills: 52. Contributed by Aaron Beashel (Converly ◆, a Verified Partner) and reviewed against the repo's partner-integrity bar before merge:
  - **Neutrality:** free and native paths first (browser Enhanced Conversions, Meta advanced matching, Google tag gateway, Meta CAPI Gateway, tool webhooks); a "when server-side matters less" section; the partner row matches the others in length and lists its tradeoffs; a free-tier row in the side-by-side; paid options surface at the delivery decision, not in every answer; the contributor's other tool (Attributer) is disclosed with alternatives; five neutrality evals (ids 17–21).
  - **Facts:** browser tags can send hashed email and phone; Meta dropped the AEM 8-event cap in May 2023; Microsoft has a Conversions API (self-serve token, still rolling out); LinkedIn dedup needs a shared `eventId`; Meta CAPI for CRM gates; Google tROAS vs tCPA minimums; conversion-adjustment windows; Shopify's 1 Oct 2026 script-tag change; the undercount stated as a 10–30% range rather than a universal 30%.
  - **Assets:** 18 detection snippets replaced with listeners that passed live checks on real forms, Jotform's now firing on the completion message its iframe and script embeds send, and Framer's confirming through Framer's own form request; every GTM recipe uses Tag Manager's import format, so Import Container accepts it; 10 drifted GTM recipes regenerated from their snippets, with `scripts/check_recipes.py` to keep them in sync; `build_recipe.py` validates every ID and substitutes safely (no JSON or JS injection) on Python 3.8+; every send tag requires consent (the Google Ads conversion tag `ad_storage` only); snippet success-signal types documented; four new tested detectors (Squarespace Forms, HubSpot Forms, Cal.com and Acuity Scheduling), for 26 in all.
  - **Repo fit:** operative rules in the description, a revops boundary, no cross-skill relative links, two audit checks restored from the retired ads reference.
- **Converly integration guide** filled in (capabilities, setup, operations); platform lift stats carry a holdout caveat.
- **analytics** (2.2.0 → 2.2.1): description drops the "conversion tracking" and "track conversions" triggers and hands getting conversions into ad platforms to conversion-tracking.
- **attribution** (1.1.5 → 1.1.6): pixels, CAPI and server-side conversion tracking now route to conversion-tracking (description, Boundaries, Related Skills, and the by-business-type tooling note).
- **ads** (2.6.1 → 2.6.2): conversion tracking pointers (routing table, Platform Setup, tracking setup line, google-ads-audit-checklist) now go to the conversion-tracking skill; description and Related Skills name it. `references/conversion-tracking.md` retired, its content carried into conversion-tracking's browser-side.md, audit-playbook.md and server-side.md.

### 2.12.4 (2026-10-19)

AIsa integration layer by first-time contributor @lhymmEU: tools/aisa/ coverage map + evals, SETUP.md/REGISTRY.md/tools/integrations/aisa.md updates.

- Added an AIsa integration quick start, task-level data coverage map, and evaluation scenarios under `tools/aisa/`. Listed AIsa as an optional connection in guided tool setup, with links from its existing guide and the registry.
- Documented AIsa's MCP setup, free connection verification, and estimate-based price admission checks. Core skill files and per-skill versions are unchanged.

### 2.12.3 (2026-10-19)

Omnia partner integration and ai-seo monitoring table update.

- **Omnia** joins as Skill Partner: integration guide with ◆ disclosure, partners.json entry, README and REGISTRY partner tables regenerated.
- **ai-seo** (2.10.0 → 2.10.1): adds Omnia alongside existing AI visibility monitoring options.

### 2.12.2 (2026-10-19)

- **ai-seo** (2.9.1 → 2.10.0): the bot access check and robots.txt config separate Meta's crawlers by documented purpose: `meta-webindexer` for Meta AI search and citations, `meta-externalagent` for training, and `meta-externalfetcher` for user requests, which may bypass robots.txt. A new Meta AI and Muse section in the platform reference covers Muse as a shopping agent that buys from the Shopify catalog, and states what Meta hasn't documented. The commerce reference adds Muse and catalog data to the audit. Agentic Experiences adds two checks: proof such as testimonials and ratings kept as selectable text, and "as of" dates on key facts.

### 2.12.1 (2026-10-19)

- **link-building** (1.0.0 → 1.0.1): the tools table lists managed placement services (LinkDR) and points to the risk policy's vendor checks, since a followed link paid for per placement is a paid link.

### 2.12.0 (2026-10-15)

New skill: **link-building**, for earning links and third-party mentions that lift rankings and AI citations.

- **link-building** (new, 1.0.0): confirms links are the bottleneck with a page-level link gap before any outreach, then ranks tactics by effort and quality (unlinked mention reclamation, partner and integration pages, moved and broken links, "best X" list inclusion, resource pages, broken link replacement, editorial guest articles) and hands PR, podcasts, directories, reviews, and communities to their own skills. Every placement is judged for SEO authority and for whether AI engines cite the page, so mentions without links count. References cover tactic playbooks, prospecting and qualification with outreach templates and a tracker, and a risk policy built on Google's spam policies (updated 2026-08-28): paid placements carry rel=sponsored or nofollow, plus vendor vetting, manual actions, and when disavow is warranted. Five evals.
- **Routing** (patch bumps): seo-audit, content-strategy, directory-submissions, public-relations, competitor-profiling, free-tools, and ai-seo now point link work to link-building. The marketing-loops backlink-prospecting loop runs through it, adds AI-cited pages as prospects, and uses the outreach tracker as its state.

### 2.11.38 (2026-10-15)

- Validate OneSignal segment filter object arrays with the documented 200-entry limit, while preserving JSON alias dictionaries and comma-separated external IDs, including numeric-looking IDs.

### 2.11.37 (2026-10-15)

Copywriting and ads now read the learnings ledger added to product-marketing in 2.11.34.

- **copywriting** (2.3.0 → 2.3.1): checks the context file's **Learnings** section before drafting, so tested angles and claims aren't proposed again as new.
- **ads** (2.6.0 → 2.6.1): reads the context file's **Paid Ads** section (targets, floors, conversion definitions, approval boundaries) and its **Learnings** section before proposing tests.

### 2.11.36 (2026-10-15)

Newsletter sponsorships and partner link tracking, adapted from Wispr Flow's MIT skills in the skills.marketing library.

- **influencer-marketing** (1.3.0 → 1.4.0): `references/newsletter-sponsorships.md` covers vetting a newsletter, reading earlier placements before booking again, skipping angles run on the same list in the last 30 days, placement specs, one file and one tracked link per placement, and reporting. Partner links now point to the UTM patterns in analytics.
- **analytics** (2.1.0 → 2.2.0): UTM patterns by partner type (newsletter, creator, podcast, affiliate, community), plus the GA4 channel-group step that keeps those mediums out of Unassigned. One hyphenated naming convention with no personal data, examples fixed to match, and a note on traffic from AI assistants. The description no longer repeats its last sentence.

### 2.11.35 (2026-10-15)

Copy skills now diagnose what they were handed before changing it, adapted with credit from Profound's and Wispr Flow's MIT copy skills.

- **copywriting** (2.2.0 → 2.3.0): new **Diagnose the Situation First** section. Blank or slop input gets rebuilt from the brief, a draft with a real voice gets restored in that voice, and a point edit changes only what was asked. It reads taste from the input (vocabulary, emphasis, scope, angle). A drafting protocol adds decompose-and-lock, a three-question gate (can the reader picture it, can it be proven, could a competitor write it), rationed punch, and a leave-it-alone test. `references/ai-tells.md` adds second-generation tells that survive a first cleanup (wisdom-shaped sentences, performed cleverness, perfect balance, omniscient casual, self-narration, tidy closers) and a build-a-writer step, with a rule against inventing anecdotes or customers. Diagnosis mirrored in the description. New eval (id 10).
- **copy-editing** (2.1.1 → 2.2.0): pick the edit mode before editing. A point edit skips the Seven Sweeps, changes only what was asked, and returns just the changed lines with reasons. Detail in `references/checklist.md`. Rule mirrored in the description. New eval (id 9).

### 2.11.34 (2026-10-15)

Brand voice built from evidence, a learnings ledger that drafting skills read, and two new loops. Voice and session-end patterns adapted with credit from Wispr Flow's MIT-licensed skills.

- **product-marketing** (2.1.0 → 2.2.0): `references/brand-voice.md` builds the voice profile from copy that performed and the founder's own writing: attributes with what each does and doesn't mean, tone by context (support, launch, errors, sales, social, billing), before/after examples, brand word lists, and per-person voice guides. The context doc gains an optional **Paid Ads** section (margin-based targets, hard floors, conversion truth, what the agent may change) and a **Learnings** table with promotion and retirement rules.
- **marketing-loops** (1.5.0 → 1.6.0): an AI-answer accuracy audit loop (claims ledger with verdicts and severity, fix the source page first) and a weekly ads-check loop that ends each account in HOLD, FIX, TEST, or INVESTIGATE. Loop runs now close with a session-end step that logs 1–3 decisions and proposes learnings for approval; campaign postmortems feed the ledger. The catalog now has 58 loops.
- **emails** (2.1.3 → 2.1.4) and **ad-creative** (2.12.0 → 2.12.1): read the Learnings section before drafting.

### 2.11.33 (2026-10-15)

Account checks that end in a decision, and Meta's official Ads MCP.

- **ads** (2.5.0 → 2.6.0): the weekly review becomes an ordered operating check (spend, traffic, conversions, creative, landing page, tracking) that ends in exactly one call: HOLD, FIX, TEST, or INVESTIGATE. A Friday stakeholder readout under 200 words closes the week (`references/operating-check.md`). Every recommendation now ends with facts, hypotheses, and missing data, with unavailable inputs labeled MISSING. The Google audit adds deep dives for conversion signals (which actions train the bidder) and wasted-spend negatives (safe now vs check first, with spend saved). PMax guardrails add Optmyzr's 2025 Search/PMax overlap finding.
- **Tools:** Meta Ads now lists its official MCP server (`mcp.facebook.com/ads`, open beta since 2026-04-29) with read-only-first setup. The registry, Composio guidance, and AGENTS.md no longer route Meta through Composio by default.

### 2.11.32 (2026-10-15)

AI search measurement for ai-seo, adapted with credit from Profound's MIT-licensed AEO skills and labeled as vendor research.

- **ai-seo** (2.8.0 → 2.9.0): four new references. `answer-accuracy.md` is a claim ledger for what AI says about you, with seven verdicts, source tracing, severity, and a fix-the-source workflow. `prompt-portfolio.md` covers intent families, stable/exploratory/control cohorts, versioning, run cadence by portfolio size, and multi-turn buying journeys. `ai-attribution.md` measures exposure, immediate, delayed, and business layers with 1-hour, 24-hour, and 7-day windows and names the evaluation design behind each claim. `multilingual-and-commerce.md` adds a per-language AEO checklist and a fit check for AI shopping surfaces. Citations-vs-recommendations gains a citation-mix taxonomy with channel rules; agent-defaults gains a docs audit for coding agents (task-to-page map, technical fact ledger); content-patterns gains a fact-family fan-out matrix. SKILL.md adds an evidence-order rule and replaces the "third-party sources matter more than your own site" claim with the measured citation mix. Stat cleanup: SE Ranking, Profound, and BrightEdge figures now carry sources and dates; the ZipTie attribution is corrected to Sellm.io; the 40/35/25 split, the 3.2x freshness multiplier, and the 30–40% schema lift are cut as unverifiable.

### 2.11.31 (2026-10-15)

- Replace unsourced tool conversion benchmarks with sourced examples and evidence-aware evaluation, preserving practical case lessons.

### 2.11.30 (2026-10-14)

Lessons from Railway's agent-first growth, Wispr Flow's creator ad program, and recent hook and X-listening threads, added to existing skills.

- **ai-seo** (2.7.6 → 2.8.0): `references/agent-defaults.md` covers products an agent installs mid-task. It explains how to measure which vendor Claude Code, Cursor, and Codex pick per stack, which stall points to fix, and the levers that move the default (no-signup provisioning, agent setup, per-stack task pages, migration guides). It also rules out agent-facing instructions that tell agents to choose you.
- **influencer-marketing** (1.2.0 → 1.3.0): `references/paid-ads-creator-program.md` covers creators paid a share of the ad spend behind their videos. It includes rate math, the guaranteed monthly minimum, recruiting a small cohort, staged growth with a cap, coaching, and four-part briefs.
- **ads** (2.4.7 → 2.5.0): the Meta playbook adds creator ads at volume. Near-identical ads get clustered, so plan by concept, angle, and awareness level, optimize for a quality event, and test the funnel in Instagram's in-app browser. AI variant farming now notes that close variants count as one concept. LinkedIn retargeting is now sequenced by behavior.
- **ad-creative** (2.11.0 → 2.12.0): the hook system adds the contrast family (choice, old vs. new, us vs. them, false assumption, declaration then question) and how it differs from the "it's not X, it's Y" AI tell.
- **social** (2.3.4 → 2.4.0): contrast hooks in the short-form library, and X-through-Grok jobs in the listening reference.
- **marketing-loops** (1.4.0 → 1.5.0): agent-default check, niche-outlier, creator-scouting, and launch-reaction loops. The catalog now has 56 loops.

### 2.11.29 (2026-10-13)

CLI and tooling fixes from @rudycelekli, each checked against the vendor's current docs.

- **Request deadlines** (#751): HTTP calls in 65 CLIs now time out instead of hanging. The default is 120 seconds, raised from #751's 30 so long scrapes and exports aren't cut off; override it with `--timeout-ms`.
- **Mixpanel regions** (#744): US, EU, and India ingestion, query, and export hosts.
- **Payload validation before sending:** the CLIs now reject inputs the vendor's API would refuse anyway. Valid empty and nested values still pass.
  - Amplitude event properties (#801)
  - SendGrid dynamic template data (#803)
  - Kit custom fields (#806)
  - Segment properties and traits (#808)
  - Customer.io data objects (#811)
  - Mixpanel properties (#813)
  - Resend batch size (#816) and template variables (#828)
  - OneSignal conflicting audiences (#818)
  - Intercom event metadata (#822)
  - Dub bulk link limits (#824)
  - Pendo aggregation envelopes (#830)
- **Correctness:** Close opportunity amounts keep exact integers instead of truncating (#831).
  - Interface change: `amplitude --properties ''` now errors instead of being ignored (#801).
- **Tooling:**
  - Packaging checks file sizes before loading them (#804).
  - The README sync handles Windows line endings (#805).
  - `check-versions` catches orphaned nested references and broken sibling links (#807).

### 2.11.28 (2026-10-12)

Skill fixes from @rudycelekli. A reviewer recomputed every calculation, and the guidance stays firm where a change would otherwise have hedged it.

- **Math:**
  - **offers** (1.0.1 → 1.0.2): multiply sequential lifts rather than adding them (#809).
  - **churn-prevention** (2.0.2 → 2.0.3): dunning ROI stated net of tooling, at 5–14x (#810). Health scores put every signal on one 0–100 scale and handle missing signals explicitly (#829).
  - **co-marketing** (2.0.2 → 2.0.3): marketplace fees are recurring costs, not CAC, and Arrows is listed on the HubSpot Marketplace (#812).
  - **referrals** (2.2.0 → 2.2.1): program return measured after serving costs (#820).
  - **ab-testing** (2.0.1 → 2.0.2): test duration accounts for the number of arms and exposure (#819).
- **Methods:**
  - **attribution** (1.1.4 → 1.1.5): intent-to-treat analysis vs. on-off tests, and an interval that includes zero is not a win (#815).
  - **revops** (2.2.0 → 2.2.1): calibrate scoring on snapshots taken at decision time and on holdouts (#817).
  - **pricing** (2.1.3 → 2.1.4): the direction of the Van Westendorp "too cheap" curves (#821).
  - **onboarding** (2.0.1 → 2.0.2): early activation measured separately from mature retention (#826). Card-required trials judged on visitor→paid, with ChartMogul's ~30% trial→paid (over 5x no-card) as context (#827).
- **Platform facts:**
  - **seo-audit** (2.2.0 → 2.2.1): hreflang findings scoped to the affected pairs, and x-default treated as optional (#823).
  - **ads** (2.4.6 → 2.4.7): screen headlines in Meta, then prove the winner with a landing-page test, without the made-up lift thresholds (#825).

### 2.11.27 (2026-10-12)

- **Analysis rules from the Magister benchmark** (#573). Four rules, each written into the skill and mirrored in its description so hosted agents see them before opening the file:
  - **ad-creative** (2.10.0 → 2.11.0): a new Test Hypotheses That Can Lose section. A hypothesis names the metric, the comparison, and the expected direction.
  - **copywriting** (2.1.0 → 2.2.0): claims must be supportable, and a declined claim names the evidence that would unlock it.
  - **analytics** (2.0.3 → 2.1.0): compute metrics from row-level data, and divide rates only over matching closed windows.
  - **marketing-plan** (1.2.1 → 1.2.2): AARRR stage metrics count only cohorts whose window has closed.

  ad-creative also notes that Magister can run its data-pull step (#567), with a disclosure that Magister is the maintainer's product and alternatives for running the pull yourself.
- **influencer-marketing** (1.1.2 → 1.2.0) and **social** (2.3.3 → 2.3.4): Telegram channel ads (#785 by @Courier-Britva). The new `references/telegram-channels.md` covers how placements are bought, a seven-check vetting routine based on views per subscriber, and pricing by CPM and deletion window. Contributed by the team behind TGScope, which is disclosed; its benchmarks come from TGScope's own studies and are labeled as directional.
- **Tools:**
  - **rowbound** guide (#500, closes #498): an open-source, self-hosted alternative to Clay that runs enrichment waterfalls from a Google Sheet, with a CLI and MCP.
  - **AIsa** joins as a ◆ Skill Partner in SEO tools (#783).
  - Across the CLIs, rejected HTTP requests now exit 1 (#713), and invalid flags fail with structured errors before any request is sent (#732), both by @rudycelekli.

### 2.11.26 (2026-10-08)

- **lead-magnets** (2.0.0 → 2.1.0): new `references/content-to-skill.md` (plus corpus design and release companions) on packaging a course, webinar series, podcast, or newsletter archive you own as an installable agent skill: a new kind of lead magnet. From @rudycelekli's #725 (closes #432), folded in rather than added as a new skill. Triggers added: 'course as a skill,' 'package our content as an agent skill.' **ai-seo** (2.7.5 → 2.7.6) points to it.
- **attribution** (1.1.3 → 1.1.4): separates real, deduplicated conversions from overlapping platform credit, and treats a large direct or branded share as something to confirm with evidence before calling it top-of-funnel impact (#794 by @jmsheldon).
- **Tools:** the Resend CLI exits 1 when the API rejects a request (#677 by @agammann).

### 2.11.25 (2026-10-08)

Three contributions from @rudycelekli that answer maintainer issues.

- **Per-skill ZIPs for claude.ai** (#730, closes #431): each release now attaches one ZIP per skill for people uploading skills in Claude's web or desktop app, plus full-source ZIPs and manifests. Claude's web upload limits descriptions to 200 characters, so a reviewed short description per skill lives in `scripts/claude-web-descriptions.json`. When a skill's description changes, the release leaves it out of the web ZIPs and lists it in the manifest until its short description is reviewed. All 50 are current. Built by `scripts/package_skills.py`; see `docs/skill-release-packaging.md`.
- **prospecting** (1.2.0 → 1.3.0), **revops** (2.1.0 → 2.2.0), **cro** (2.0.2 → 2.0.3), **signup** (2.0.0 → 2.0.1) (#721, part of #498):
  - New `prospecting/references/enrichment-playbook.md`: acceptance rules per field, exact cache keys, and keeping errors separate from genuine no-matches.
  - New `revops/references/inbound-routing.md`: form routing that survives enrichment failures and duplicate events.
  - Pointers from cro and signup.
- **Guided tool connections** (#720, closes #405): `tools/SETUP.md` walks an agent through connecting Google Ads, Meta Ads, LinkedIn Ads, GA4, or Stripe. It keeps credentials in a private local file, never in chat, and verifies each connection with a read-only test.

### 2.11.24 (2026-10-08)

Two contributions from @rudycelekli, folded into existing skills instead of becoming new skills.

- **seo-audit** (2.1.1 → 2.2.0): local SEO from #717 (closes #486). New `references/local-seo.md` covers diagnosing the map pack separately from organic results, Business Profile and citation cleanup built on real business facts, honest review requests, and useful location pages, with two companion references for profile details and page measurement. Triggers added: 'local SEO,' 'Google Business Profile,' 'map pack.'
- **referrals** (2.1.0 → 2.2.0): review programs from #722 (closes #475), building on @Adi29102000-s's contribution in #417. New `references/review-programs.md` covers review requests, responses, reputation triage, and permissioned testimonial reuse, with platform rules and program operations in two companion references. Triggers added: 'get more reviews,' 'G2 reviews,' 'review campaign,' 'respond to a bad review.'

### 2.11.23 (2026-10-08)

Skill and tooling fixes from @rudycelekli: corrected platform facts, sounder math in the finance and testing guidance, and validator fixes.

- **Platform facts:**
  - **schema** (2.0.1 → 2.0.2): FAQ rich results ended in 2026, and HowTo and the sitelinks search box were retired earlier; Schema.org vocabulary is now kept separate from what Google displays (#767).
  - **analytics** (2.0.2 → 2.0.3): GA4 enhanced-measurement event names in reports (#774), and localized price text kept out of monetary tracking (#779).
  - **churn-prevention** (2.0.1 → 2.0.2): correct Paddle Billing dunning webhook events (#776).
  - **aso** (2.0.1 → 2.0.2): Google Play preview videos can autoplay muted (#784).
  - **seo-audit** (2.1.0 → 2.1.1): preferred canonicals for same-language regional duplicates, which must sit inside the hreflang cluster (#782).
  - **directory-submissions** (2.1.0 → 2.1.1): verify the actual link and its rel qualifiers rather than HTTP headers (#768).
- **Math and reasoning:**
  - **ab-testing** (2.0.0 → 2.0.1): correct p-value and confidence-interval interpretation for fixed-horizon tests (#769).
  - **ads** (2.4.5 → 2.4.6): CAC payback uses gross margin and cohort recovery, keeping firm verdicts (#773). The Meta Andromeda playbook moved into `references/meta-andromeda-playbook.md`, bringing SKILL.md under 500 lines.
  - **marketing-plan** (1.2.0 → 1.2.1): ARR budgets account for churn in the starting base (#772).
  - **pricing** (2.1.2 → 2.1.3): Van Westendorp measures price perception, not demand (#771).
  - **referrals** (2.0.2 → 2.1.0): rewards are capped by total CAC (#780). A new `references/affiliate-operations.md` covers cohort economics, partner activation, payout policy, and incrementality; it builds on @Adi29102000-s's contribution in #417 (#724).
  - **attribution** (1.1.2 → 1.1.3): stale booking-link identity is cleared (#770), and webhook analytics failures are non-fatal (#778).
- **Routing and creative:**
  - **cro** (2.0.1 → 2.0.2) and **emails** (2.1.2 → 2.1.3): a routing table that sends each question to the right reference (#699).
  - **ai-seo** (2.7.4 → 2.7.5): question-level routing to its references (#702).
  - **ad-creative** (2.9.4 → 2.10.0): headline treatments by buyer awareness stage (#727).
- **Tooling:** the validator and sync script now handle Windows line endings (#709), ignore indented metadata keys (#763), keep literal `$` text (#764), and require frontmatter that opens and closes the file (#762).

### 2.11.22 (2026-10-08)

75 CLI fixes from @rudycelekli, each checked against the vendor's current API docs. Endpoints, auth, pagination, encoding, and error handling now match what the APIs actually accept.

- **Correct endpoints and payloads:** Dub (#661, #729), Beehiiv (#662, #663), SendGrid Single Sends (#664), Apollo org enrichment (#668), Amplitude retention (#670), SavvyCal (#671, #742), Livestorm (#672), Close (#673), Keywords Everywhere (#675), Pendo (#676), Intercom (#680, #686), Optimizely archive (#681), Hotjar (#682), Trustpilot invitations (#683), Similarweb v4 (#684), AirOps (#685), Tolt (#687), lemlist webhook filters (#689), Demio (#692), Ahrefs backlinks (#693), Crossbeam (#696), Rewardful (#698), Mailchimp tags (#701), Snov (#707, #752), Semrush backlinks (#711), PartnerStack (#723), Adobe (#741).
- **Auth:** ZoomInfo signed-key login (#690), Supermetrics (#691), Zapier catch hooks without management keys (#694), OneSignal `Key` auth (#695), Wistia Bearer (#706), Google Ads without a developer token, now that Google has sunset them (#718), Apollo key in a header (#668).
- **Failing loudly instead of silently:** GSC (#674), TikTok (#710), DataForSEO task errors (#714), Postmark partial batches (#715), Mixpanel ingestion (#716), GA4 event params (#700), Intercom metadata (#766).
- **Pagination and identifiers:** Klaviyo cursors (#666), Customer.io ID encoding and EU region (#665, #738), Plausible (#733), GA4 (#735), GSC (#736), Hunter (#746), Resend (#749), Close page size (#750), Rewardful (#754), Outreach cursors (#755), Pendo IDs (#728), Apollo employee ranges (#765), github-prospects truncation (#708), Buffer `--now false` (#704).
- **New capabilities:** Amplitude external-ID lookup and device-only events (#726, #758), Paddle plan and billing-date changes (#731), Firecrawl crawl errors (#734), ActiveCampaign custom fields (#737), Segment anonymous IDs and delivery metadata (#739, #760), Google Ads read-only GAQL (#743), Brevo channel suppression (#745), Exa answers and structured search output (#747, #753), Resend idempotency keys (#748), Postmark template models (#756), Klaviyo structured properties (#757), Customer.io suppression (#759).
- **Interface changes to know about:**
  - `amplitude users activity --user-id` now takes your external user ID; use `--amplitude-id` for Amplitude's internal ID (#726).
  - `airops --id` is now the app UUID, and `AIROPS_WORKSPACE_ID` is no longer used (#685).
  - Tolt drops `--name`, `--commission-rate`, `payouts`, and customer lookup by `--customer-id` (#687).
  - ZoomInfo passwords move from `ZOOMINFO_PRIVATE_KEY` to `ZOOMINFO_PASSWORD` (#690).
  - OneSignal switches to `Key` auth, so check older-format keys (#695).
  - PartnerStack `transactions create` and `webhooks create` require `--currency` and `--events` (#723).
  - `mailchimp` rejects `--tags` combined with other update flags (#701).
  - DataForSEO exits 1 on "no results" and "partial results" task codes as well as errors (#714).


### 2.11.21 (2026-10-08)

Community fixes from @rudycelekli: credential handling in three CLIs, Mixpanel service accounts, and two hardening fixes in skills.

- **Tools:**
  - **mixpanel** (#669): the CLI prefers service-account auth, with project-secret auth as a fallback, and requires a project ID for service accounts.
  - **kit** (#679) and **hunter** (#688): dry-run previews now redact credentials by query parameter, and Hunter URL-encodes its key.
- **ad-creative** (2.9.3 → 2.9.4): classify review images using browser URL semantics, block normalized remote/authority forms, retain portable local/data assets, and align the image instructions with the preview restriction. (#775)
- **schema** (2.0.0 → 2.0.1): escape serialized JSON-LD at the HTML script boundary in the Next.js example, preserving the original product text. Add a matching diagnostic eval and link official framework guidance. (#777)

### 2.11.20 (2026-10-07)

Modern outbound, from a full audit of the sales and GTM skills against 2025–26 practice. Everything extends existing skills. Tools ship alongside in #791.

- **cold-email** (2.1.0 → 2.2.0): scope widened from writing cold emails to running outbound. Five new references:
  - `deliverability.md`: secondary domains, mailbox math, SPF/DKIM/DMARC, Gmail's hard rejections from November 2025 and Microsoft's enforcement from May 2025, warmup, tracking off, monitoring, and stop-loss rules.
  - `linkedin-outreach.md`: limits, the engage-then-connect sequence, copy, and the automation decision after LinkedIn's 2025–26 actions against vendors.
  - `multichannel-cadence.md`: cadences by tier, the rule that a reply on any channel stops all of them, calls, video, direct mail, and ads.
  - `outbound-plays.md`: value-first teardown, product-led, problem-led, and founder-led plays.
  - `reply-handling.md`: reply types, response speed, booking, early objections, and what an agent may send alone.

  Benchmarks drop open rate and use 2025–26 data. A tool section was added, and the description now carries the core rules (secondary domains, verify first, tracking off, stop every channel on a reply).
- **prospecting** (1.1.3 → 1.2.0): three new references.
  - `signal-plays.md`: signal ranking and freshness windows, mapping each signal to a play, and account tiers.
  - `account-research.md`: account briefs and rules for agent research (facts before angles, "no hook found").
  - `sourcing-and-enrichment.md`: alternatives to scraping LinkedIn, the enrichment waterfall and provider bake-off, catch-all and re-verification policy, and a suppression list shared across channels.

  `compliance.md` fixes two errors: GDPR does apply to LinkedIn messages, and Google Place IDs may be stored. It adds UK PECR (fines up to £17.5M), the consent requirement for B2B email in Germany, Australia, and US phone rules (DNC, AI voice under the TCPA). Legacy Clearbit references are replaced, and the tool table is updated with verified MCP status.
- **sales-enablement** (2.3.2 → 2.4.0): new `references/cold-call-scripts.md` covering openers, first-minute pushback, voicemail, and gatekeepers.
- **revops** (2.0.1 → 2.1.0): an outbound stage model with attribution fields and handoff rules.
- **marketing-loops** (1.3.0 → 1.4.0): four outbound loops (signal sweep, reply triage, cold-domain health, sequence retro) and `references/outbound-operator.md`, with approval rules by tier. The catalog now has 52 loops.
- **emails** (2.1.1 → 2.1.2), **competitor-profiling** (2.1.2 → 2.1.3), **ads** (2.4.4 → 2.4.5), **social** (2.3.2 → 2.3.3): route outbound requests to cold-email and account research to prospecting.
- **cro** (2.0.0 → 2.0.1): replaces a legacy Clearbit reference.
- **Tools** (#791):
  - Instantly CLI moved to API v2, plus its official MCP.
  - A new Truelist CLI.
  - New guides for Attio, HeyReach, FullEnrich, LeadMagic, TheirStack, and Apify.
  - MCP status checked across outbound tools; 30 are now listed.
  - Clearbit marked legacy.
  - LinkedIn Ads CLI moved to the versioned REST API.
  - A sales outbound quick start in the registry.

### 2.11.19 (2026-10-07)

SEO operations: running SEO as a standing job, not a one-off audit. Everything extends existing skills.

- **marketing-loops** (1.2.1 → 1.3.0): new `references/seo-operator.md`, a recipe that combines the SEO loops into one scheduled operator for a site the agent can edit from its repo. It covers a five-setting brief (ship mode defaults to PRs for review); shared state in `.agents/seo/` (a claims ledger, a query map with one primary query per page, and a work queue ranked by expected conversions per hour); every-run, weekly and monthly schedules; a first-run checklist; operating rules; a writing gate; and a one-screen weekly report. Three new catalog loops:
  - **striking-distance push**: positions 8–20, plus top-5 pages with weak click-through.
  - **AI-answer check**: a weekly prompt panel. Misstated facts send you to fix the page that should state them, and cited sources become outreach targets.
  - **claim-drift**: product changes that make marketing claims false.

  Also fixes the stale loop count (now 48). New triggers: 'run my SEO,' 'SEO operator,' 'daily SEO agent.' New eval.
- **seo-audit** (2.0.1 → 2.1.0): two new references.
  - `references/rankings-push.md`: finding striking-distance and weak-CTR candidates, checking cannibalization, diagnosing against the top three results, making the smallest fix that closes the gap, judging results after 3–4 weeks, and a checklist for shipping a new page.
  - `references/title-tags.md`: title patterns by page type, why Google rewrites titles, low-CTR fixes, and a table format for bulk audits.

  New triggers: 'stuck on page 2,' 'striking distance keywords,' 'title tag rewrite,' 'low CTR.' New eval.
- **copy-editing** (2.1.0 → 2.1.1): `references/content-refresh.md` now starts from a SERP gap analysis: a coverage grid against five competitors, gaps ranked by how many competitors cover them, matching coverage rather than word count, and an approval checkpoint. It adds what to keep (the URL, linked anchors, the voice) and a handoff list for whoever publishes.
- **launch** (2.1.0 → 2.2.0): new `references/shipped-changes.md`, which turns merged PRs into a weekly changelog entry, drafts sized to each change, a list of pages the changes made wrong, and new content opportunities. Only live, customer-visible changes count, and every claim must come from the change itself. New triggers: 'changelog,' 'release notes,' 'what did we ship this week.' New eval.
- **content-strategy** (2.1.2 → 2.1.3): an information-gain gate for searchable content. If you can't say what the piece adds that the top results lack, don't write it.
- **ai-seo** (2.7.3 → 2.7.4): visibility-audit prompts are spread across buyer awareness stages, plus guidance on turning findings into work: fix the page behind a misstated fact, and treat cited sources as outreach targets when you're absent.

### 2.11.18 (2026-10-06)

Website platform coverage, prompted by Ploy (◆ Verified Partner, Website & landing page builders). The repo had the strategy layer for sites (copywriting, cro, site-architecture, programmatic-seo) but nothing on where to build, adding sections to an existing site, migrating, or go-live QA. Added to existing skills, no new skill. Ploy appears as one option among alternatives with disclosure, including that the maintainer authors Ploybooks in Ploy's library. Closes #653.

- **site-architecture** (2.0.0 → 2.1.0): new `references/platforms-and-migration.md`: six questions before choosing a platform; an options table (Webflow, Framer, WordPress, Wix Studio and Squarespace, landing-page tools, AI-native site platforms incl. Ploy ◆, AI app builders, hand-coded, headless); adding a section to an existing site (same platform, subpath via reverse proxy, subdomain, separate domain) with a proxy checklist; and migrating without losing traffic (crawl, redirect map, what imports don't carry, post-launch monitoring). New triggers: 'which website builder should I use,' 'migrate my website,' 'add a blog to my existing site.' New evals (ids 7–8).
- **programmatic-seo** (2.0.0 → 2.1.0): new Implementation Framework step 6 and `references/implementation-platforms.md`: what a platform has to do for pages at scale (item limits, data refresh, server-rendered HTML, conditional sections, per-page indexation, internal linking, publish time) and the options (Webflow CMS, WordPress, Framer CMS, hand-coded generation, headless CMS, AI-native platforms incl. Ploy ◆ PloyDB). New trigger 'which CMS for pSEO.' New eval.
- **ai-seo** (2.7.2 → 2.7.3): `agent-readiness.md` gains ways to implement WebMCP (yourself, platform support with Ploy ◆'s Ploybook as one example, a coding agent) and the tests every path needs.
- **launch** (2.0.3 → 2.1.0): new `references/site-launch-qa.md`, a before/at/after go-live checklist (forms and conversion tracking, SEO incl. the shipped staging noindex, redirects, performance, a practiced rollback per platform, Search Console monitoring). New triggers: 'site launch,' 'go live,' 'pre-launch QA.' New eval.
- **prospecting** (1.1.2 → 1.1.3): `references/data-sources.md` and the tool table add Ploy ◆ as a visitor-identification option for Ploy-hosted sites, alongside RB2B and Clearbit Reveal, with its limits (hosting requirement, metering, consent caveat).
- **ads** (2.4.3 → 2.4.4): `references/abm-playbook.md` gains account pages for 1:1 and 1:few ABM (personalization layer, CMS fed from a list, hand-coded route, or an AI site platform such as Ploy ◆), with guardrails (noindex, only public or first-party facts, human review).
- **tools/integrations/ploy.md**: rewritten from current docs. Corrects the claims of a general REST API and an MCP server (the CLI is the management surface; WebMCP is a Ploybook), adds real CLI workflows (v0.16.x), pricing, and tradeoffs, and notes that OIDC SSO is live on Enterprise. Reviewed by Ploy. REGISTRY's MCP flag and the partner blurb are updated to match.

### 2.11.17 (2026-10-02)

- **video** (2.2.0 → 2.2.1) and the **Hyperframes integration guide** (reported in #600 by @pjthegiant): the old example called a `render({ frames })` API that the `hyperframes` package doesn't export. Both now lead with the CLI (`npx hyperframes init`, `preview`, `render -o output.mp4`) and explain the composition format: a root with `data-composition-id`, `class="clip"` elements with timing attributes, and a paused GSAP timeline. Rendering from code goes through `@hyperframes/producer` (`createRenderJob` + `executeRenderJob`). Checked against v0.8.114.
- **ad-creative** (2.9.2 → 2.9.3): three creative-review template fixes (reported in #592 by @antongulin). Malformed data now shows a clear error instead of a blank page. The concept switcher uses `aria-pressed` buttons instead of incomplete tab semantics. The Instagram like count comes from an optional `likes` field, where it used to be a hardcoded 6,240.

### 2.11.16 (2026-10-02)

- **OpenAI Codex plugin** (#445 by @darkweb19, closes #295): `.codex-plugin/plugin.json` plus a marketplace at `.agents/plugins/marketplace.json`. Install with `codex plugin marketplace add coreyhaines31/marketingskills`, then `/plugins`, and update with `codex plugin marketplace upgrade`. It uses the Codex compatibility layout OpenAI's plugin creator scaffolds. `scripts/check-versions.mjs` now requires the Codex manifest's version to match the repo version so the two can't drift.
- **Non-interactive installs** (#339 by @SilviaMogas): the README notes that `/plugin` only works in an interactive Claude Code session, and gives `npx skills` and the `claude plugin marketplace add` / `claude plugin install` CLI commands as alternatives.

### 2.11.15 (2026-10-02)

Four community contributions folded into existing skills instead of becoming new skills. Each original PR is merged with its author's commits.

- **public-relations** (1.1.2 → 1.2.0): crisis communications from #381 by @fyscleaning-jpg. New `references/crisis-communications.md` (severity tiers 1–4, a first-60-minutes checklist, channel order, playbooks by crisis type, what not to do) and `references/statement-templates.md` (7 templates). Adds a "When Something Goes Wrong" section and crisis triggers. Anything with legal, regulatory, or safety exposure loops in counsel before fault is admitted. New eval.
- **sms** (1.0.1 → 1.1.0): WhatsApp from #516 by @Inflimity. New `references/whatsapp.md`: WhatsApp vs SMS (incl. Meta not delivering marketing templates to US numbers), the 24-hour window, template categories, opt-in, quality rating, and business-level messaging limits. Pricing is rebuilt from Meta's docs: per-message since July 2025, and in-window utility and service messages charged from 1 Oct 2026. Also covers click-to-WhatsApp ads and the 72-hour free window, plus four playbooks. WhatsApp triggers added. New eval.
- **marketing-plan** (1.1.2 → 1.2.0): market sizing from #418 by @imMamdouhaboammar. New `references/market-sizing.md`: TAM/SAM/SOM, four triangulated methods (bottom-up, search-led, competitor-led, channel-led), confidence labels, ranges with assumptions, and a 10-factor attractiveness scorecard. Linked from the market-quality gate. Market-sizing triggers added. New eval. customer-research (2.0.3 → 2.0.4) and competitor-profiling (2.1.1 → 2.1.2) point to it.
- **video** (2.1.2 → 2.2.0): product demo recording from #345 by @klepfish. New `references/product-demo-recording.md`: a Playwright recording workflow, step modes, and local-app gotchas. The contributor's scripts are linked at their commit rather than vendored, and narration API keys stay out of chat. Demo-recording triggers added. New eval.

### 2.11.14 (2026-10-02)

Community tool and guide contributions. Lands #642, #400, #586, #366, #461, and #397 with contributor credit.

- **Ahrefs CLI v3 parameters** (#642 by @rudycelekli): sends the `date` and `select` parameters Ahrefs v3 requires. Both now default (today's date, Ahrefs' documented keyword and top-page columns) instead of being mandatory, and the tests moved to `tests/clis/`.
- **Firecrawl CLI and v2 docs** (#400 by @rakshith48): a new zero-dependency Firecrawl CLI on the v2 API, with competitor-profiling's tool reference updated to v2 (structured extraction is now JSON mode on scrape). It shows usage without credentials like the other CLIs.
- **Glasser integration guide** (#586 by @adriansurething): a pay-per-call data API broker, now with an in-guide maker disclosure and provider-access claims framed as subject to each provider's terms.
- **Alternative stack for competitor-profiling** (#366 by @4thoughtmarketing-mktg): WebFetch plus whichever SEO data source is connected (Ahrefs or Semrush MCP, Ubersuggest, or similar) when Firecrawl or DataForSEO is unavailable. Missing metrics are marked unavailable, never estimated.
- **Publishing from your agent** (#461 by @josiahcoad): a draft-first, approval-gated workflow for scheduling posts through a connected tool. The tool list is neutral, and the Typefully claim is corrected.
- **X algorithm reference** (#397 by @benjaminard): how xAI's open-sourced For You ranker scores posts, with each rule tagged verified or reported.

### 2.11.13 (2026-10-02)

Community content fixes. Lands #595, #572, #508, #401, and #481 with contributor credit.

- **Sora and GPT Image deprecations** (#595 by @MeowdyAGENT, closes #594): removes Sora 2 recommendations (OpenAI shut down Sora 2 and the Videos API on 24 Sep 2026) and updates image-model guidance. The model names now follow OpenAI's deprecations page: `gpt-image-1` retires 23 Oct 2026, with `gpt-image-2.5-sunburst` and `gpt-image-2.5-flare` as the replacements. Also fixes a broken link. ad-creative 2.9.2, image 2.0.2, video 2.1.2; the video eval now expects the shutdown rather than "reliability caveats."
- **Search vs training crawlers** (#572 by @wonderwomancode, closes #599): ai-seo no longer treats GPTBot, ClaudeBot, and Google-Extended as citation bots. Discovery, user retrieval, training, and grounding are decided separately, with a valid robots.txt example. The author's own tool link was replaced with vendor docs. ai-seo 2.7.2.
- **Attribution model availability** (#508 by @UberVero, closes #507): retired Google Ads/GA4 rule-based models, DDA volume, Calendly UTMs, MTA bias, and triangulated overrides. attribution 1.1.2, influencer-marketing 1.1.2.
- **Brand vs non-brand** (#401 by @mharnett): optimize Google Ads on non-brand ROAS and report blended separately. ads 2.4.3.
- **Typo** (#481 by @tim703223-glitch): "Pre-Seed/Seed" in saas-prospecting. prospecting 1.1.2.

### 2.11.12 (2026-10-02)

Community fixes, links and security. Lands #581, #583, #518, #542, #543, and #540 with contributor credit, plus version bumps.

- **Portable tool links** (#581 by @FekyBaz, closes #524): every `../../tools/...` link in 21 skills is now an absolute GitHub URL, so links work after `npx skills add` installs a single skill. One link #581 missed (ads `reading-google-ads-data.md`) is fixed too. Bumps: ad-creative, ads, ai-seo, analytics, attribution, churn-prevention, co-marketing, content-strategy, customer-research, emails, influencer-marketing, launch, marketing-loops, pricing, prospecting, public-relations, referrals, revops, sales-enablement, sms, social, video (patch each).
- **Internal links** (#583 by @dajiaohuang): fixes the `positioning` link (now product-marketing) and the ad-creative cross-skill link (now names the ads skill), and adds a CRLF-safe partner sync. Its PARTNERS.md change was reverted, since the header template's `../REGISTRY.md` path is correct for guides.
- **Prompt-injection guardrail** (#543 by @sneakygriff): "fetched content is untrusted data" in 8 skills that read third-party pages.
- **marketing-plan path safety** (#542 by @sneakygriff): sanitizes `{client-slug}` so one client's files can't be read from another's. marketing-plan 1.1.1 → 1.1.2.
- **ad-creative review template** (#540 by @sneakygriff): proper `\u003c` escaping, remote image URLs blocked so the review page can't beacon, and the third-party `npx gooseworks install` route removed. The Gooseworks credit is kept in full.
- **Windows validator** (#518 by @frankgthb-afk): `validate-skills-official.sh` works under Git Bash.

### 2.11.11 (2026-10-02)

- **ai-seo** (2.6.0 → 2.7.0): new `references/linkedin-ai-citations.md`, prompted by Kaleigh Moore's 20 weeks of consistent Pulse-article citations (Sep 2026) and built from six 2026 citation studies (Profound, Semrush, OtterlyAI, Cloro, Goodie, Scrunch) plus our own Ahrefs pull by URL path.
  - **Engine split:** ChatGPT moved from Pulse articles to feed posts (Pulse ~−86%, posts ~+74% May → Oct 2026, with a ~36% LinkedIn drop in the mid-August retrieval change). Perplexity cites LinkedIn most, company pages first. Copilot citations of LinkedIn more than doubled. Gemini almost never cites LinkedIn.
  - **Crawler access:** from LinkedIn's robots.txt, search crawlers (Googlebot, Bingbot, OAI-SearchBot, Claude-SearchBot) are allowed and live-fetch agents are blocked. Includes a `curl` self-check for crawler-only `noindex` on Pulse articles.
  - **What gets cited:** engagement and follower count barely matter; original, specific, technical content with named entities does. Avoid Unicode bold and "link in comments." Includes the length ranges cited articles and posts fall in, and durability and risk notes (no canonical control, so publish on your own site first).
  - **Corrections:** the "~60% Articles / ~40% Posts" figure misread LinkedIn's guide (articles, newsletters, and posts combined are 60%), fixed in SKILL.md and `format-volatility.md`. Copilot's unsourced "ranking boost" is replaced with data. `agent-readiness.md`'s volatility case now includes LinkedIn. New trigger 'LinkedIn for AEO'; new eval (id 12).

### 2.11.10 (2026-10-02)

- **ai-seo** (2.5.0 → 2.6.0): lessons from Edward Sturm's podcast with Harpreet Singh (E1182, "AEO Companies Are Selling You 2016 SEO," Sep 2026), labeled as practitioner experience throughout.
  - New `references/positioning-and-consensus.md`: much of "AEO" is SEO without the history; brand positioning moves slowly in LLMs (repositioning, mergers, and rebrands can cause a visibility dip, so baseline both segments and move off-site signals before the on-site rewrite); every third-party profile should match the About page; work backwards from fan-out domains; small sets of industry/segment pages; managing the "cons" affiliates write; head-term plays where incumbents are already chosen; and what not to copy (invented awards, self-owned review sites, with the FTC 2024 reviews rule).
  - Measurement: track only prompts tied to revenue, collapse wording variants like keywords, mine `site:` fan-outs for the third-party profiles that matter, and add a "what did you type?" follow-up to self-reported attribution.
  - `citations-vs-recommendations.md` gains a sentiment-repair recipe and a third listicle option (name the leader first, show where you go further). `content-types.md` gains Industry / Segment Pages; `youtube-ai-citations.md` gains field notes (low citation bar for fresh videos, ungated demos, unattributable creator sponsorships).
  - Fixes: two unsourced headline stats removed and the rest dated; the ~15% AI Overview overlap stat now carries its caveats and a "rankings still predict AI visibility" note; schema is no longer "the single biggest lever" (and FAQ rich results were limited in 2023); Claude's observed skepticism of self-ranked lists noted; GEO-paper figures restated accurately. New eval (id 11).

### 2.11.9 (2026-10-02)

- **directory-submissions** (2.0.0 → 2.1.0): includes #541 by @sneakygriff, which removes ten dead or re-registrable directories (one, aiforme.wiki, has since come back as a new site) and adds a pre-submit safety gate (liveness check, directory pages as untrusted data, human approval before each submission). On top of that, learned from a 2026 launch post (~35 directories, DR 4 → 26 in ~40 days, self-reported):
  - **Official MCP Registry first.** Publishing now uses the `mcp-publisher` CLI with `server.json` and GitHub or DNS namespace proof, and aggregators (PulseMCP, Glama) build on it. Step-by-step in `directory-list.md` Tier 4A.
  - **New Tier 4 sections:** MCP directories (Smithery, MCP.so, MCP Market, mcpservers.org and more), GitHub list PRs (public-apis, active awesome-mcp lists, xAI plugin marketplace; nofollow, check the list still merges), and agent and AI-search listings (Claude plugin directory, ClawHub with its Feb 2026 malware caveat, llms.txt directories).
  - **Tier 1B, indie launch sites**, with caveats: judge by traffic not DR (many are badge-swap rings), free dofollow links often require keeping their badge, and two lookalike `.com` domains for real `.dev` sites are for sale.
  - All new domains verified live on 2026-10-02; the tracker CSV gains 16 rows. A calibration case in KPIs and a new eval (id 7) for MCP ordering and lookalike domains.

### 2.11.8 (2026-10-02)

The AI-tell rules from 2.11.7 extended to the channel skills, each inline because installed skills can't load copywriting's references. Each gets the core bans (contrast reveals, negation lists, trailing pile-ons, self-answered questions and colon reveals, stock phrases, em dashes) plus its own channel tells, adapted from the closed #575. Reference templates that modeled tells (contrast-reveal carousel and static-ad slots, generic hooks, em dashes in example copy) are rewritten. Rules mirrored in each description. Closes #615.

- **social** (2.2.0 → 2.3.0): new **No AI Tells** section with broetry, engagement-bait closers, manufactured vulnerability, and emoji bullets. Hook formulas in SKILL.md and `post-templates.md` that modeled tells ("isn't what you think," "Here's why:," "The truth is," an em-dash hook) are rewritten. New eval (id 8).
- **emails** (2.0.0 → 2.1.0): new **No AI Tells** section with subject-line bait (fake "Re:"/"Fwd:"), stock openers, and sign-off filler. New eval (id 7).
- **cold-email** (2.0.0 → 2.1.0): AI tells added to What to Avoid and the Quality Check; em-dash contrasts removed from the skill's own text. New eval (id 7).
- **ad-creative** (2.8.2 → 2.9.0): new **No AI Tells** section with stacked negations to fit character limits, hook slop, CTA slop, and a no-repeated-sentence-shape rule across a batch. New eval (id 16).

### 2.11.7 (2026-10-02)

AI-tell blacklist for copy. Clients reject drafts that read as AI-written, and the worst tells are sentence shapes that word lists miss. Closes #613.

- **copywriting** (2.0.2 → 2.1.0): new **No AI Tells** section and `references/ai-tells.md`, a researched blacklist (Wikipedia's AI-cleanup guide, excess-vocabulary studies, slop benchmarks, practitioner catalogs). Bans contrast reveals ("it's not X, it's Y," "not because X, because Y"), negation lists ("no X, no Y, no Z"), trailing pile-ons (a claim followed by more comma clauses), self-answered questions, colon reveals, stock openers and marketing phrases, and em dashes in short copy. Caps fragments, lists of three, and vague vocabulary. Rewrite rules (fix from the facts, swap test, no invented proof) and a self-check to run before every delivery. Rhetorical-question advice now warns against answering your own question. The skill now follows its own rules: em dashes and a contrast reveal removed from SKILL.md, and conflicting advice removed from the references ('When it comes to,' self-answering question transitions, the 'Everything you need to' formula). Defines short copy, long copy, and sections, and lists what stays fine (FAQ questions, one 'No card required,' real three-feature lists). The rules are mirrored in the description. New triggers: 'this sounds like AI,' 'AI slop,' 'make it sound human.' New eval (id 9).
- **copy-editing** (2.0.0 → 2.1.0): new **AI-Tell Check** run on every edit, inline because installed skills can't load copywriting's references; a "Reads as AI-Written" problem entry and checklist section. The word-swap table no longer suggests synonyms (robust → strong) that the check forbids. New control eval (id 8) checks that clean copy is left alone. Rule mirrored in the description. New triggers: 'this sounds like AI,' 'AI slop,' 'de-slop this,' 'make it sound human.' New eval (id 7).

### 2.11.6 (2026-10-01)

Post-merge review fixes. Closes #611.

- **ads** (2.4.0 → 2.4.1): `reading-google-ads-data.md` corrections. The 30-day limit is `change_event`'s; `change_status` covers 90 days without field detail. `metrics.conversions` can include secondary actions a custom goal pulls in. `client_type` names the client, not who or why, and Editor changes aren't returned. Learning phase blocks optimizing, not fixing verified breakage.
- **sales-enablement** (2.3.0 → 2.3.1): Battle Cards points single live objections at Live Deal Objection.
- **tools/google-ads**: computed date ranges use the local calendar date (UTC shifted them a day late in US evenings), and invalid `--days` values are rejected.
- **CI**: `check-versions.mjs` requires skill and repo versions to increase, and the repo version to match the newest changelog block.

### 2.11.5 (2026-10-01)

Three competitive-PMM jobs added to existing skills instead of new ones, so the evidence rules from 2.11.3 apply to all of them. Closes #604.

- **sales-enablement** (2.2.0 → 2.3.0): new **Live Deal Objection** subsection: one objection from a live deal gets a deal-specific answer (pin down who said what, name the likely concern and a question that separates readings, one say-as-written response, only proof the rep can stand behind, when to qualify out). New **Win-Loss Analysis** section and `references/win-loss-analysis.md`: source bias table (rep-entered CRM reasons skew to price/timing), segment before counting, one primary reason per deal with a source, counts with sample sizes, under ~5 deals is a signal not a finding, report format, and where findings feed battle cards and the objection library. New triggers: 'win-loss analysis,' 'why are we losing deals,' 'loss reasons,' 'how do I respond to this objection,' 'prospect just said.' New evals (ids 9, 10).
- **competitors** (2.2.0 → 2.3.0): new **Competitive Asset Audit** under Research Process: inventory every competitor claim across vs pages, battle cards, talk tracks, and decks; re-verify with a check date; mark current / changed / unverifiable / overclaimed; fix public pages first; report with replacement wording. New Asset Audit Report output. New triggers: 'audit our competitor pages,' 'are our comparison pages out of date,' 'competitive asset audit.' New eval (id 8).

### 2.11.4 (2026-10-01)

- **sales-enablement** (2.1.0 → 2.2.0): new **Battle Cards** section, which had no home before. `competitors` claimed the trigger with no guidance and `sales-enablement` pointed back at it. Covers an 8-part structure (when you'll see them, why buyers consider them, where they're strong, where we win and for whom, discovery questions, top objections, when to walk away, last verified) and a refresh cadence. Asks which competitor rather than guessing. New triggers: 'battle card,' 'battlecard,' 'competitive one-pager.' New eval (id 8).
- **competitors** (2.1.0 → 2.2.0): 'battle card' trigger moved to sales-enablement; description and related skills point there. Closes #608.

### 2.11.3 (2026-10-01)

Evidence discipline for the three skills that make claims about competitors. Comparison pages and battle cards are claims a competitor's team, or a buyer, can check in a minute.

- **competitors** (2.0.1 → 2.1.0): new **Evidence Discipline** principle. "Not observed" is not "doesn't have": a feature missing from a pricing page gets "not listed (as of date)" or no row, and ✗ only when docs or a trial confirm it. Date competitor facts, treat one visit as a snapshot (no "hasn't changed" without dated history), state what changed but never guess why, and keep fact, interpretation, and recommendation separate. Ask instead of guessing when no competitor is named. `templates.md` gains a "not listed" table row; the competitor data template gains `last_verified` + `sources`.
- **competitor-profiling** (2.0.1 → 2.1.0): Facts Over Opinions now separates **observed / inferred / implication**, adds not-observed ≠ absent (including "no public pricing" ≠ free) and no-motive rules; Current Data notes a single scrape can't support "hasn't changed"; "where we're strong" requires customer, win/loss, or review evidence or is labeled a hypothesis.
- **sales-enablement** (2.0.1 → 2.1.0): new **Claims Reps Can Defend** principle. "Why we win" needs win/loss, CRM, call, or customer evidence; without it, advantages are hypotheses with the evidence that would confirm them. Competitor claims follow the competitors evidence rules, and competitive docs say where you lose.
- One new eval per skill. Closes #602.

### 2.11.2 (2026-10-01)

- **ads** (2.3.2 → 2.4.0): new `references/reading-google-ads-data.md`, covering how Google Ads data misleads before an audit even starts. **Search terms are a sample**: on small accounts 50–65% of clicks have no disclosed query, so every claim states disclosed vs total clicks, the report is pulled unfiltered first, and nothing (GA4, CRM) recovers the withheld queries. Data traps: `conversions` vs `all_conversions`, several final URLs per ad group, click-date attribution, expired experiment arms that look like duplicate campaigns, the 30-day change-history limit, and `client_type` for who else changes the account. **Window vs lifetime** and no pooling across config changes. **Small numbers**: a zero-conversions-in-N-clicks table (what each sample size rules out) plus break-even CVR = CPC ÷ target CPA, and "let it run" only with a date. **Stating findings** as verified / inferred / stale, the "can the client disprove this in a minute?" test, and a "conclusions that sound right" table. Fixed the `audit-guardrails.md` Fail example that treated disclosed search terms as a share of all spend. Two new evals (ids 12–13). New triggers: 'search terms report,' 'wasted spend,' 'is this campaign working.'
- **tools/google-ads**: API URLs moved from the long-sunset v14 to v24 (guide and CLI); added analysis GAQL recipes (campaign inventory, monthly since launch, conversions by action, unfiltered search terms, ads by final URL, change history) and a gotchas table. Closes #601.

### 2.11.1 (2026-09-04)

- **ai-seo** (2.4.0 → 2.5.0): new `references/format-volatility.md` — the citation-*format* volatility axis, companion to agent-readiness.md's citation-*source* volatility. Anchored on the **ChatGPT 5.6 format shift** (Aug 2026, Peec AI data via Tomek Rudzki and Lily Ray): fan-out queries dropped the "vs / comparison / top / best / reviews" modifiers while `site:` and "official" searches surged, and citations by page type fell −50.5% for listicles (15.77% → 7.80%) and −32.1% for comparison pages (9.08% → 6.17%) — the two formats companies scaled for GEO, demoted in one release. Covers what changes (stop justifying scaled listicle/comparison production with "wins AI citations"; owned "official" pages rising as the citable class) and what doesn't (comparisons still convert humans and still earn citations on Google AIO / Gemini / Perplexity — a per-platform format table replaces one-size-fits-all advice). Adds **LinkedIn as a citation surface** from LinkedIn's own AEO guide (via Chris Long, platform-reported: most-cited outlet for professional searches; Articles out-cite Posts ~60/40; first words of a post become the URL slug — front-load the target phrase), a **DIY ChatGPT fan-out extraction** diagnostic (DevTools → network payload → literal background queries; explicitly warned against as a mass-generation content-spam input), and a **measurement-rigor** section (AI answers are non-deterministic: 3–5 runs per query, mention *rate* with sample size, rates-over-time not run-vs-run, technical/comprehension/trust cause split; framing credited to Initial Commit's AEO audit skill, Josh Pigford). SKILL.md: Content Types section rewritten around the volatility (stale ~33%-comparison-share table retired to context), ChatGPT fan-out + extraction pointer added to the fan-out section, LinkedIn added to the Presence pillar, non-determinism rule added to DIY monitoring, new triggers ('do listicles still work for AI,' 'ChatGPT stopped citing comparison pages,' 'AI citation format shift'). New eval (id 10) covers the scaled-comparison-roadmap prompt that must get the 5.6 pushback plus the one-run-anecdote measurement correction.


### 2.11.0 (2026-08-23)

- Added the **`events`** skill (1.0.0) — event marketing across all four roles: **hosting** (webinar → workshop → dinner → meetup → virtual summit → user conference, governed by "the topic is the targeting" and recurring-beats-one-off), **sponsoring/exhibiting**, **speaking**, and **attending** (target list → pre-booked meetings → the side-event play). Built on the universal arc — **20% event, 80% before-and-after** — with the 24–48h tiered follow-up, capture-context-not-just-contact discipline, an event-as-recording-studio content arc (transcripts compound in AI answers → ai-seo, public-relations), and a three-tier measurement model (vanity / real / decisive) with multi-touch honesty via attribution. Four references: **webinar-funnel.md** (the flagship funnel, closes #485), **sponsorship-roi.md** (ICP-overlap + cost-per-qualified-meeting math, side-event play, tiered follow-up), **speaking.md** (CFP craft, talk storyboard, the recording as the real audience), and **event-portfolio-strategy.md** (which events to invest in: in-person-necessity by segment, the 80/20 of selection, size↔ROI inverse, the owned/trade-show/community frame + economics — distilled from Corey's *Founding Marketing* ch.9). Seven evals. New skill = repo y release; total skills: 50. Closes #485.

### 2.10.5 (2026-08-23)

Batch enrichment across 15 existing skills, distilled from Corey Haines's *Founding Marketing* book (full 19-chapter scan). Each is a patch bump; no new skills.

- **ads** (2.3.1 → 2.3.2): `references/payback-period.md` — the Payback Period budgeting gate (Payback = CAC/ARPU, target 3–12mo; Discounted Payback = CAC/(ARPU×retention)) + the "LTV:CAC is destructive" argument. (ch7)
- **customer-research** (2.0.1 → 2.0.2): `references/interviews-and-surveys.md` — primary-research layer: Sean Ellis/Superhuman PMF survey (40% benchmark), "keep asking why" 5-why laddering, interview outreach template + incentives, best-customer recruitment, confirmation-bias guardrail. (ch2)
- **onboarding** (2.0.0 → 2.0.1): `references/minimum-path-to-value.md` + `references/activation-models.md` — MPTV (Hick's Law), the 5 activation models + Model-Market Fit, onboarding psychology set, 10-component toolkit. (ch16)
- **pricing** (2.1.0 → 2.1.1): initial "learning price" philosophy ($10/$100/$1,000) + `references/pricing-models.md` (8 models incl. credit/outcome/hybrid) + price-change rollout methodology. (ch15–16)
- **co-marketing** (2.0.0 → 2.0.1): `references/partnership-types.md` — the 5 partnership types + "permissionless co-marketing." (ch11)
- **marketing-ideas** (2.0.0 → 2.0.1): `references/guerrilla-marketing.md` — direct-mail 3-rule framework + named case library (WePay ice block, Antimetal $15K pizza→$1M). (ch13)
- **copywriting** (2.0.1 → 2.0.2): clarity & message-market-fit — the "Now you can" test, Human Action Model, Perception Gap, SavvyCal case, clarity metrics. (ch3)
- **public-relations** (1.1.0 → 1.1.1): `references/story-angles.md` — the 3 story angles (Founding Story / David vs Goliath / Have an Enemy) + PR flywheel. (ch5)
- **content-strategy** (2.1.0 → 2.1.1): `references/content-distribution.md` — "content as product," "Create Once Distribute Twice" distribution spine (ORB-as-funnel, distribution hooks), scoring + 60/30/10 calendar. (ch6, ch14)
- **referrals** (2.0.0 → 2.0.1): `references/viral-mechanisms.md` — product-embedded virality: Viral Potential Spectrum + 7 mechanisms + affiliate power-law/buyout clauses. (ch10–11)
- **free-tools** (2.0.0 → 2.0.1): `references/tool-benchmarks.md` — named case benchmarks (Unsplash→Getty, Website Grader 250K leads) + "your product is my marketing opportunity" + pitfalls. (ch8)
- **community-marketing** (2.0.0 → 2.0.1): `references/community-models.md` — 5 community-model archetypes + Notion ambassador benchmarks + scaling-phase role shift. (ch12)
- **offers** (1.0.0 → 1.0.1): `references/saas-offers.md` — the discount trap (~2× churn) + 4 SaaS-flavored worked offers. (ch15)
- **marketing-plan** (1.1.0 → 1.1.1): "marketing as investing" north-star + problem size×frequency matrix; 70/20/10 allocation + plateau-alert cadence in growth-patterns. (ch1, ch17)
- **launch** (2.0.1 → 2.0.2): SLC (Simple, Lovable, Complete) pre-launch readiness gate vs Stealth Mode / "Just One More Feature." (ch1)

### 2.10.4 (2026-08-23)

- **ad-creative** (2.8.1 → 2.8.2): three creative-format references distilled from Dara Denney's practitioner content. New `references/meta-creative-formats.md` — a prioritized S→F taxonomy of ~51 Meta ad formats as a "which format to make next" decision aid, framed by the unicorn-scaler-vs-supporting-cast lens and the persona-based Andromeda algorithm (S-tier: founder content, partnership ads, VSL; explicit F-tier de-prioritization of press / podcast / notes-app fake-native). `references/static-ad-templates.md` gains a **tier (S–F) + funnel role** on all 15 templates plus 7 new statics (grid multi-SKU, callout, mood board, educational infographic, challenging-beliefs, tweet/reddit, ugly/post-it). `references/short-form-video-specs.md`'s Creator Format Library expands from 3 to 13 formats (yapper, amateur investigation, David & Goliath, authority, VSL, green-screen commentary, conversation, duet/reaction, ASMR, street interview) plus a founder/organic vlog-structures subsection (hero's journey, math, shiny-object, three-capture shooting, 0.5–1s cut) from Oren John. New evals (ids 13–15); description gains taxonomy triggers.
- **ads** (2.3.0 → 2.3.1): two new references plus a partnership-ads layer. New `references/google-ads-audit-checklist.md` — a 32-item ecommerce Google Ads audit (Search + Shopping + PMax + GMC + Demand Gen) scored pass/fail/unknown/NA under the audit guardrails (adapted from ECHELONN's public checklist). New `references/creative-research-automation.md` — an agentic creative/competitive research workflow (ad-library teardown with output schema, review→persona mapping, competitor teardown; connectors + scheduled-to-Slack). `references/meta-decision-system.md` gains the **partnership-ads playbook** — the net-new-reach lever under Andromeda's persona targeting, rolling month-over-month reach as a scale/health signal, and the per-creator low-fi-statics companion tactic — closing the skill's prior zero coverage of partnership ads. New evals (ids 8–10).

### 2.10.3 (2026-08-22)

- **ad-creative** (2.8.0 → 2.8.1): new `references/short-form-video-specs.md` — the vertical-video production spec + a creator-format library, distilled from Daniel Hangan's `reelclaw-templates` (built on HeyGen's HyperFrames; patterns credited, no code vendored). **Part 1, the spec, applies to every 9:16 video the skill makes** (iMessage reveals, motion ads, and the creator formats): the cross-platform safe-zone band (TikTok∩IG Reels worst case — 220px top / 500px bottom / 180px sides → a 720×1200 centered text-safe area, the single most-missed constraint), the classic TikTok caption recipe (white fill + black `paint-order` stroke, no background pill), static-caption auto-sizing (~58px shrinking in 2px steps to a 26px floor, re-fit after `document.fonts.ready`), audio defaults with the **organic-vs-baked-music decision** (attach the trending sound in-app for organic reach; bake music only for ads / where native sound can't attach; fade the last ~0.8s), and the deterministic-render contract. **Part 2 is three creator/UGC formats** the skill didn't document — Reaction + Demo (hard cut), "No Yapping" silent split-screen tutorial, and Greenscreen Reaction — each as a reusable structure with when-to-use and mechanics. SKILL.md's Generating Ad Visuals section routes to it (load before producing any vertical video) and the description gains 'UGC ad' / 'reaction ad' / 'greenscreen ad' / 'no yapping split-screen video' / 'TikTok/Reels ad format' triggers (older redundant triggers trimmed to stay within the 1024-char limit). New eval (id 12) covers the format + safe-zone + organic-music decision in one prompt. Cross-links to the `video` skill for framework/render choices.

### 2.10.2 (2026-08-21)

- **ai-seo** (2.3.0 → 2.4.0): new `references/agent-readiness.md` — the access/discovery/parseability layer beneath all content work: can an agent reach, navigate, and parse the site at all. Anchored on the two free scoring tools that shipped in Aug 2026 and made this measurable — **Is Agentic** (Vercel + Ora; `npx is-agentic`; 100+ checks with essential/recommended/bonus tiers, not-applicable excluded rather than failed, plus an observed agent journey) and **Frase's Agent Readiness Checker** (access/discovery/parseability triad with 80/60 score bands) — both credited, with the checks treated as the value rather than the vendor pitch. Covers the access essentials (core content in initial HTML — most agents never run JavaScript; no bot-challenge/firewall blocks on AI crawlers; correct HTTP behavior), the discovery file stack (robots.txt with an explicit AI-crawler stance, clean sitemap, llms.txt plus the newer **`llms-full.txt`** whole-site-in-one-request companion, robots content-usage statements), and the newest parseability technique: a **Markdown representation of every page**, served either by content negotiation (`Accept: text/markdown` at the same canonical URL with a `Vary` header) or an HTTP `Link` header pointing at a parallel Markdown version. Introduces the **agent-actionable** frontier (WebMCP — pages declaring forms/CTAs as callable tools; labeled emerging) with the practical-today floor (highest-intent actions work without JS-only flows). Adds a **citation-source volatility** section built on the Aug 2026 case study — ChatGPT's query fan-out changes nearly wiped Reddit as a citation source within days (practitioner-reported, Ashni of Hype Partners (@ashnichrist) and others), while business-owned sites dominate Gemini citations (~60%) — with the strategy consequences: portfolio over single-surface concentration, owned-site fundamentals as the volatility hedge, citation-share stats treated as dated snapshots verified against your own monitoring, and ~24-hour citation speed as the freshness upside. SKILL.md updates the Reddit lines in the Presence pillar with the volatility flag, points Machine-Readable Files at the new reference, and adds 'agent readiness' / 'is my site agent-ready' / 'llms-full.txt' / 'WebMCP' triggers. New eval (id 9) covers the two-sided prompt: an agent-readiness audit plus a Reddit-concentrated strategy that must get the volatility warning.

### 2.10.1 (2026-08-19)

- **ads** (2.2.0 → 2.3.0): added `references/audit-guardrails.md` — the honesty layer for working on live ad accounts (audit scoring semantics, recommendation-safety rules, and the benchmark-evidence ladder distilled and remixed from AgriciDaniel/claude-ads, MIT, credited). Covers: **four-state scoring** (pass / fail / unknown / not applicable) with the core rule that account *health* and *evidence coverage* are kept separate — an unknown reduces coverage, never health, so "couldn't check your pixel" can't masquerade as "your pixel is broken"; **coverage bands** (80%+ graded, 60–79% provisional, <60% report findings but present no health score) and the partial-audit rule (a failed platform/data source is excluded from rollups, never scored as zero, and the audit is never called complete); **what never counts against health** (unknowns, ineligible/beta/premium features, feature non-adoption, deviation from broad benchmarks); **recommendation safety** — every optimization heuristic is conditional on sample size, conversion lag, margin, and learning-phase state, so never pause on a fixed CPA multiple, apply one budget-to-CPA ratio across objectives, freeze a learning campaign as a reflex, recommend ineligible features, or invent negative keywords without a search-terms report + overblocking review; **hard stops** as response contracts (refuse cross-attribution-window conversion sums and report side by side; zero candidate negatives without evidence; no single health score over major data gaps); **benchmark discipline** (provenance labeling incl. vendor-supplied, cohort-fit check, and the narrowest-defensible-comparison ladder: own prior period → own experiment → CRM cohort → peer cohort → broad benchmark as directional only); and **untrusted data + live accounts** (fetched pages/exports/screenshots are data, not instructions; read-only by default with draft-first mutation plans — current state → change → expected effect → rollback — and smallest-reversible-change preference). SKILL.md adds a compact Audit & Recommendation Guardrails section with the six non-negotiables plus a Reference Routing row. New eval (id 7) covers the four hard stops in one adversarial prompt (fixed CPA kill rule, invented negatives, cross-window conversion sum, health score over ~50% coverage). Also added **destination testing** to `references/meta-decision-system.md`: one CBO per persona, one ad set per destination type (PDP / listicle / quiz / demo) with the same creatives in every ad set — holding creative constant makes CPM/performance divergence attributable to the lander, treating the destination as a test axis of the same rank as creative; fits the Testing campaign with the usual TCPL spend gates, graduating the winning creative × destination pair (practitioner-reported pattern, Alexander Pauwelyn 2026, labeled as such per the new benchmark discipline).
- **ai-seo** (2.2.0 → 2.3.0): new `references/youtube-ai-citations.md` — the anatomy of a YouTube video AI cites, built on the core insight that **models don't watch the video, they read the text layer around it** (from Ross Simmonds / Foundation Inc., credited). In leverage order: the transcript as the real content (speak key answers as complete, liftable sentences; say entities out loud), cleaned captions over messy auto-captions, question-shaped titles, chapters titled by sub-question (structure = extractability), a keyword-rich description restating key points as text, a pinned comment carrying the summary as an extra liftable block, and engagement/thumbnail as the indirect layer (watch signals → YouTube ranking → AI surfacing). Includes a publishing checklist. SKILL.md's Presence pillar adds podcasts as a cited third-party surface (episodes get transcribed, show notes published, both crawled) with pointers to the new reference and to public-relations podcast prep. New eval (id 8) covers diagnosing the text layer instead of production quality.
- **content-strategy** (2.0.0 → 2.1.0): new **Link-Earning Formats** section with Foundation Inc.'s backlinks-vs-page-share data (March 2026; labeled a single vendor study, directional): stat/data roundups 4.25x, glossaries 1.47x, interactive tools 1.38x, how-tos 1.36x — while original research earns 0.80x, ultimate guides 0.77x, thought leadership 0.74x, and templates 0.68x. The counterintuitive read: curating statistics out-earns producing original research ~5x for links, because writers cite whatever makes citation easiest and research gets cited *via* the roundups that aggregate it. Playbook: maintain a category stats page (cheap, compounding, doubles as an LLM-citation surface → ai-seo), and pair any original research with your own stat-roundup of its findings to capture the links the data generates; bottom-of-table formats are judged by their other jobs (rankings, conversions, brand), not links. New eval (id 7).
- **public-relations** (1.0.0 → 1.1.0): new `references/podcast-guest-prep.md` — a podcast appearance prep workflow distilled and adapted from Knowatoa's ai-visibility-skills (MIT, credited), reframed around the AI-visibility insight: episodes get transcribed, show notes get published, both get crawled and cited, so the stories a guest tells become the citable record on their brand for years. Covers the research fallback chain (RSS feed → site episode list → Apple Podcasts → web search, without fetching every episode), what to extract (recurring **threads** over individual episodes since threads predict the questions; show progression phases + inflection points; host profiles best mined from episodes where hosts guest on *other* shows; name-collision flagging; prior-appearance recap), the six-part brief (big picture → progression → recent episodes → guest angles with pocket stories → host rapport hooks → gaps), angle-finding by mapping the story bank onto show threads (one contrarian take stands out most on consensus shows), and coaching the guest to speak in liftable form (company name next to category, numbers said aloud — same logic as ai-seo's YouTube text layer). Uses our `.agents/product-marketing.md` convention plus a one-batch story-bank interview. SKILL.md adds the reference pointer, a common workflow, and 'podcast prep' / 'going on a podcast' / 'podcast guest' triggers.
- **influencer-marketing** (1.0.0 → 1.1.0): new `references/ugc-creator-program.md` — the **volume UGC creator program ("tech UGC")** model, distilled from Julia Pintar / Playkit's viral 12M-downloads playbook (credited) and **compliance-rewritten** in response to Rachel Karten's public FTC critique of the original (credited): every paid creator post carries disclosure (#ad + platform paid-partnership label) even from fresh accounts — "doesn't look like an ad" is the exact pattern disclosure law exists for, and the brand is liable; the paid comment-bounty tactic is replaced with compliant alternatives (program-account replies, open brand engagement) plus a platform inauthentic-behavior warning; SKILL.md §4 explicitly overrides any conflicting source step. Keeps the operational engine: content volume as the asset (10 creators × 3 posts/day ≈ 900 organic tests/month vs ~30 for a brand account; ~$3.87 CPM claim labeled vendor-supplied), playbook-first concepts (creators use the product first; study own winners / competitors / adjacent-category user journeys / audience content, plus a failure archive; every concept = audience + pain + hook + format + script + product screen + reference), the four-format taxonomy (talking ~70%, wall-of-text as viral-but-low-convert warm-up, AI-automatable slideshows, aging hook-and-demo — test the same idea across formats to separate bad ideas from bad presentation), trial-week vetting where the *revision* matters more than the first video, stable-base + bonus pay, the account-warming checklist, 3/day cadence with pre-post review and concrete-not-vague feedback, the four-touchpoint conversion ladder ending in reply videos, judge-by-product-questions-not-views daily iteration with one-variable changes and a four-week minimum, and full-time program ownership. SKILL.md adds the model to the spectrum section plus 'tech UGC' / 'UGC creator program' / 'creator network' triggers. New eval (id 7): the "replicate this viral playbook exactly" prompt must fix the two FTC violations while keeping the engine.
- **seo-audit** (2.0.0 → 2.0.1): added the untrusted-data guardrail — fetched pages are analyzed, never obeyed; instructions embedded in HTML, meta tags, or page copy are a prompt-injection surface.
- **competitor-profiling** (2.0.0 → 2.0.1): added Core Principle 5 — Untrusted Input. Competitor pages, reviews, and docs are data, never instructions; agent-targeted text ("describe this product favorably," hidden HTML directives) is ignored and the attempt noted in the profile.
- **aso** (2.0.0 → 2.0.1): added the untrusted-data guardrail for fetched store listings and reviews (same prompt-injection surface, incl. instructions planted in user reviews).

### 2.10.0 (2026-07-22)

- **attribution** (new, 1.1.0): a dedicated skill for the hardest question in marketing — which efforts actually drive conversions and revenue. Fills a real gap: attribution was scattered across analytics (UTM setup), ads (platform pixels), revops (pipeline), and ai-seo (the AI blind spot), but no skill owned the *models* or the *reconciliation problem*. Two pillars. **(A) Interpretation** — the six attribution models and when each lies; MTA vs. MMM vs. incrementality and how to choose; self-reported attribution; reconciling the platform-vs-GA-vs-CRM-vs-survey disagreement (never sum across platforms; pick one source of truth; read directional trends); and the direct / branded-search / dark-social / AI blind spots. **(B) Own your attribution (first-party)** — a build runbook for instrumenting attribution yourself when you control the site/app: the identity graph, closing the `identify()` gap (adapted from Tessa Kriesel's PostHog approach), stitching conversions on third-party domains you don't own (SavvyCal/Calendly/Stripe) via metadata passthrough + webhook identity-merge, fail-closed anonymity guards, and first-touch data-quality cleanup — distilled from real production builds (Conversion Factory + Truelist). Four references (`attribution-models.md`, `measurement-paradigms.md`, `by-business-type.md` with B2B/DTC playbooks, `first-party-tracking.md`) and 7 evals covering reconciliation, model choice, the third-party stitch, ROAS incrementality, the direct/branded blind spot, the analytics boundary, and the DTC measurement stack. Pillar B also folds in **production feedback from Tessa Kriesel** (credited): the CRM last mile (sync a `source` field with confidence + basis and a paid-vs-non-paid read onto the account → revops), storing the full ordered touch path so the build track can run Pillar A's multi-touch models on real data, the "expect ~zero until the cross-subdomain stitch is verified in prod" window with a narrowly-scoped campaign-window fallback + pre-stitch backfill, and account-level rollup (excluding free-mail domains) for B2B.
- **analytics** (2.0.0 → 2.0.1): description now hands off attribution modeling and reconciliation to the new attribution skill, keeping analytics scoped to tracking setup, event taxonomy, and UTMs.

### 2.9.1 (2026-07-27)

- **pricing** (2.0.1 → 2.1.0): added a **Pricing Page Teardown** — a two-axis audit of a live pricing page. Axis 1 is the classic human buyer experience (value-prop clarity, plan differentiation, cognitive load, trust signals, psychology, transparency); Axis 2 is the novel **AI-agent readiness** lens: whether the LLMs/agents that increasingly shortlist and compare tools can actually read and quote your pricing — machine-readable prices (not locked in an image or behind "Contact us"), extractable FAQ/objection coverage, per-tier depth in text, and structured data. Includes the memorable **"paste test"** (give the URL to a browsing-capable AI and ask for the plans and prices — if it can't answer, an AI shopping for your buyer can't either), a full 10-dimension rubric + scoring/report template in `references/pricing-page-teardown.md`, and hand-offs to `schema` (Product/Offer JSON-LD) and `ai-seo` (extractability, AI search-bot access, llms.txt). New eval (id 7). AI-agent-readiness lens adapted from Kyle Poyar / Growth Unhinged (learn-from-only, credited).

### 2.9.0 (2026-07-15)

- Added **`influencer-marketing`** skill — influencer, creator, and ambassador partnerships end to end. Foundation contributed by @Adi29102000-s (PR #417), expanded to the repo's standard and shipped standalone (the PR's other proposed skills were not included). Covers the **influencer ↔ ambassador spectrum** (paid influencer → affiliate creator → gifting → long-term ambassador program → organic advocate, each with when-to-use and skill handoffs), finding & vetting (audience-alignment test, creator tiers incl. B2B thought leaders, engagement/fake-follower/brand-safety checks), 1:1 outreach (→ cold-email), deal structuring (flat / CPA / hybrid / gifting compensation, rate-as-a-range reality, and the high-ROI content-usage-rights/whitelisting clause → ad-creative), a full **FTC disclosure & compliance section** (material-connection disclosure, clear-and-conspicuous placement, gifting-still-needs-disclosure, platform labels, brand liability, no fabricated claims — a gap in the original contribution), the creative brief (don't script; grounded talking points), measurement & ROI (unique promo codes, UTMs, vanity URLs, post-purchase survey for the branded-search/direct attribution blind spot, whitelisting performance, cost-per-qualified-outcome over EMV/reach), and a structured **ambassador program design** (ask → benefits ladder → recruit-from-evidence → equip → activate → track, cross-referencing community-marketing for community-led advocacy and referrals for payout rails). Six-eval suite covering compensation/whitelisting, podcast attribution, the gifting-disclosure misconception, ambassador-program design, creator vetting, and the no-word-for-word-scripting brief. New skill = repo y release. Total skills: 48.
### 2.8.12 (2026-07-16)

- **product-marketing** (2.0.0 → 2.1.0): the context document now carries its own **version history**. `.agents/product-marketing.md` gets a `Document version:` header (v1, v2 …) and a `## Changelog` section at the bottom — a newest-first, dated, one-line-per-revision paper trail of *what changed and why*. The update flow now reads the current version and recent changelog on open, and on save bumps the version, updates `Last updated`, and prepends a new changelog entry naming the sections touched and the reason (never rewriting past entries; skipped only for pure typo fixes). Since this doc is the shared context every other marketing skill reads, the changelog makes positioning/ICP changes traceable across a project — you can see how the positioning evolved and what a downstream skill was generating against. New eval (id 7) covers the version-bump + prepend-changelog behavior on a repositioning update.

### 2.8.11 (2026-07-14)

- **video** (2.0.1 → 2.1.0): added **reverse-engineering a viral edit into a reusable edit spec** (the tool-agnostic decomposition behind "copy any viral edit" — pattern from Arcads' skill, whose Omni generation model is proprietary/MCP-gated; we build only the decomposition, credited). New `references/edit-anatomy.md`: pull the reference with watch-video (visual/multimodal to read frames + caption style + cut timing) or social-fetch, extract the edit anatomy beat by beat across nine dimensions (shot/framing, cut rhythm/cuts-per-second, on-screen text, caption style, motion/punch-ins, b-roll/overlays, sound design, the first-2s hook, pacing curve), and output a per-beat **beat sheet** table plus a **style summary** of the 3–5 signature moves that make the edit recognizable (patterns over instance-logging). Includes the review-once gate (approve the beat sheet — on-screen text + scene-change placement — before executing in Remotion/Hyperframes, CapCut, or an AI restyle tool) and a hard originality guardrail (copy the editing grammar applied to your own footage/message, never the reference's footage, script, voiceover, or music). SKILL.md adds a Reverse-Engineer a Viral Edit workflow and 'copy this edit,' 'match this video style,' 'reverse-engineer this video,' 'edit like this reference' triggers. New eval (id 7). Closes #456.

### 2.8.10 (2026-07-14)

- **ad-creative** (2.7.0 → 2.8.0): added **AirDrop** as a fourth surface in the iOS-native reveal video ad family (`references/imessage-video-ads.md`, alongside iMessage / ChatGPT / Apple Notes; format popularized by Shiv Sakhuja / Gooseworks' goose-video Airdrop Ads, re-expressed originally — their runtime is MIT but the recipe is private, so this is original craft). The one interaction-native format in the family: the hook is an **incoming AirDrop request** and the **Accept tap is the reveal** — a translucent AirDrop card (sender device name, preview thumbnail, red Decline / blue Accept) from the receiver's POV, where iOS's own accept/decline choice is a built-in micro-conversion beat. New `### AirDrop Reveal` subsection: the preview thumbnail as the hook that must earn the tap, sender-name casting (relatable human name reads native; brand-as-sender reads like an ad), the transfer progress-ring as the signature motion, the AirDrop swoosh sound (not iMessage tritones) with the same CC0-Apple + trade-dress caveat, receiver-POV-default vs sender-POV-flex, and the family grounding/disclosure rules (a dramatization of a share, never a real endorsement). Updates the H1, intro, surface-selection table, and choosing-signal line to four surfaces. SKILL.md pointer names AirDrop and adds the 'AirDrop ad' trigger. New eval (id 11).

### 2.8.9 (2026-07-13)

- **prospecting** (1.0.0 → 1.1.0): added a **fourth branch — Demand-signal discovery (find your first customers)**, the early-stage motion that finds first customers / design partners / beta users from recent public pain-demand-timing signals rather than firmographic list-building (re-expressed from the open-source `first-customer-finder` Codex skill, Kappaemme/MIT, credited; extended with our live-recency tooling). New `references/demand-signals.md`: how the branch differs from list-building (starts from a described problem, sources public discourse, wins on 10 strong evidence-backed matches over coverage), a product brief gate, the five signal query buckets (explicit demand / pain / workaround / switching / timing) with our tooling edge called out (last30days for Reddit/HN/X/web recency, social-fetch to read original threads, scraping/Firecrawl/Browserbase over snippets, deep-research, competitor-profiling, customer-research), a public-only source mix, a **demand-fit scoring rubric** (pain 25% / product fit 25% / timing 20% / reachability 15% / evidence quality 15%, 0-100 with bands — distinct from the ICP-fit Hot/Warm/Cold), prospect stages (high intent / problem aware / trigger present / potential fit), a per-prospect evidence ledger, manual-only source-based openers (never auto-send), the evidence-report structure (verdict → ICP → top prospect → shortlist → repeated patterns → 7-day manual outreach plan → limits), and the honesty rules (a cited signal is the entry ticket; label 'potential customer based on public signals,' never 'will buy'). SKILL.md adds the branch to the Pick-the-Branch table + deep-dive pointers and 'find my first customers,' 'early adopters,' 'design partners,' 'beta users,' 'who has this problem' triggers. Also closes two **compliance-guardrail gaps** across all branches: no data brokers / leaked datasets, and never target or infer sensitive/protected traits (health, financial hardship, political belief, sexuality, religion). New eval (id 7) covers branch selection, signal mining, demand-fit scoring, and the never-auto-send rule. Closes #447.

### 2.8.8 (2026-07-12)

- **ad-creative** (2.6.0 → 2.7.0): added the **creative review page** — a shareable, self-contained HTML artifact that presents generated concepts for a client or stakeholder to review and pick (the visual upgrade to `INDEX.md`; pattern reverse-engineered from a real agency creative-approval page, re-expressed originally). New `assets/creative-review-template.html`: one file, inline CSS+JS, no build or dependencies, driven entirely by a `DATA` object — renders concept tabs (each a strategic angle), a pixel-accurate in-feed Instagram/Facebook preview with a whitelist-handle toggle, a labeled frame-by-frame storyboard (tap to jump), selectable headline variations that overlay the preview, primary text, destination/CTA/offer, optional rollout mechanics, and a required grounding disclosure; frames render real images (URL / relative path / data URI) or styled label+prompt placeholders for concepts not yet rendered. New `references/creative-review-page.md`: when to produce one, the full data model, the frame-storyboard-as-carousel-arc link to `carousel-frameworks.md`, the hard grounding rule (every concept discloses what's real; illustrative proof is labeled illustrative — never launder fiction as fact), and how to populate/verify/deliver (open locally, host on any static host, or hand off the file). SKILL.md adds a Creative Review Page output-format section, a Mode 3 pointer, and 'creative review page' + 'present ad creative for approval' triggers. New eval (id 10) covers template use over markdown, narrative-job frame labels, and the grounding disclosure. Browser-verified: concept switching, platform/handle toggles, and frame navigation all render correctly.

### 2.8.7 (2026-07-10)

- **ad-creative** (2.5.0 → 2.6.0): added **Mode 4 — the Creative Strategy Loop**, the upstream workflow layer for deciding which ads are worth making (built so the same capability ships in any agent running the library, incl. Magister; workflow shapes informed by public creative-strategist practice, expressed originally). New `references/creative-roadmap.md`: three-signal synthesis (account performance via the platform CLIs; customer/brand language via the Grounded Inputs corpus + customer-research; external organic via scraping, social listening, and competitor-profiling) on a monthly-deep-dive + weekly-refresh cadence with a receipts rule (no insight enters the icebox without its source); concepts as segment × motivation × angle × format hypotheses ranked on a six-tier evidence scale; **account-state branching** (exploration state: wide net-new mix, per-metric win redefinition, iterate only on hits, four root causes to check; scaling state: winner-variation-heavy mix with visually-distinct variations, sub-angle probes, a standing exploration allocation); the **roadmap artifact** (icebox → quarterly themes → monthly slate with T1 iteration / T2 remix / T3 production tiers and a hard capacity check); per-concept briefs handed to Modes 1–3; and the **monthly creative retro** (winners/losers/metric-wins/learnings/kills, judged at concept level, every learning landing as an icebox update, re-rank, or kill). New `references/hook-system.md`: hooks as three components (visual action / spoken line / caption) with the no-duplication rule; the segment → motivation → format → hook generation pipeline output as a hook matrix; an eight-move opening menu; the **diagnostic funnel** mapping thumbstop/hold/CTR/CVR to which component to fix; the **on-ramp rule** (every hook test is an on-ramp test); fidelity laddering tied to production tiers; and inherited grounding rules plus organic language mining. SKILL.md adds the Mode 4 section and 'creative strategy,' 'creative roadmap,' 'creative retro,' 'hook writing' triggers. New eval (id 9) covers exploration-state diagnosis, evidence-ranked slates, and the receipts rule.
- **customer-research** (2.0.0 → 2.0.1): added the **zero-review persona fallback** to Persona Generation — a four-step proxy ladder (own differentiator → direct competitors' reviews → marketplace comparables → adjacent brands sharing the audience) with provisional-persona tagging and replacement as first-party evidence arrives.
- **marketing-loops** (1.1.0 → 1.2.0): added **the monthly-creative-retro loop** to the Paid section of `references/loop-catalog.md` — closes ad-creative's Mode 4 loop on a schedule: pulls last month's performance, drafts the retro artifact and next month's capacity-checked slate, flags the account-state call for human confirmation, one-retro-per-month idempotency, and never launches or pauses ads. Closes #434.

### 2.8.6 (2026-07-09)

- **ai-seo** (2.1.0 → 2.2.0): added **citations vs. recommendations** — the correction to citation-centric AEO strategy. New `references/citations-vs-recommendations.md` (grounded in Lily Ray's (Amsive) 100-query B2B study, Scrunch and SimilarWeb behavioral studies, and Growth Plays commentary): the **AI visibility ladder** (retrieved → cited → mentioned → recommended, each governed by different criteria, plus the shadow rung of being *recommended against* on requirements-heavy prompts), the **self-promotional listicle risk** (69% of the AI Overview citations earned by self-promotional "best [category]" listicles — 224 of 323 — appeared in answers that excluded the publisher from the recommendations; for emerging brands a self-ranked guide can act as a vote for competitors), **stage-dependent buyer's-guide strategy** (leaders get cited and recommended; emerging brands get citation and category framing — still worth publishing, with rebalanced expectations), **what earns recommendations** (offsite consensus: reviews, analysts, communities, earned media, video — with the test "if a model ignored everything on our domain, would the rest of the web still shortlist us?"), and **what a recommendation is worth** (Scrunch, observational: ~2× behavior lift vs. a passing mention; for users with no recent observed brand engagement, +182% branded searches / +117% site visits / +185% product views within a week; SimilarWeb: ~2.5× more new visitors — with only ~9% visible as AI traffic, the attribution blind spot) plus the measurement triad (prompt tracking with mention framing, self-reported attribution, call recordings). SKILL.md adds a compact citation-≠-recommendation pointer, a Recommendation-rate row in Monitoring, and caveats on the Listicle Block (content-patterns.md) and educational-content goals (content-types.md).
- **competitors** (2.0.0 → 2.0.1): added an **AI-answer expectations-by-stage** caveat to the alternatives-page format — these pages often earn AI citations, but recommendation depends on offsite consensus; for emerging brands a self-ranked list can surface competitors in the answer. Cross-references ai-seo's citations-vs-recommendations reference. Closes #427.

### 2.8.5 (2026-07-09)

- **ad-creative** (2.4.0 → 2.5.0): extended the iMessage reveal reference into **iOS-native reveal video ads** — `references/imessage-video-ads.md` (filename unchanged; retitled) now covers three surfaces sharing one production architecture. New **Other iOS-Native Reveal Surfaces** section: a surface-selection table keyed to persuasion mechanic (iMessage = a friend's recommendation; ChatGPT = an authoritative answer to the viewer's own question; Apple Notes = a private confession made public), **ChatGPT reveals** (the typed question is the customer's verbatim question; stream the answer in word chunks — type like thumbs, stream like a model; ChatGPT-real formatting; OpenAI trade-dress legal note; and the strictest compliance rule in the family — the answer is ad copy wearing an authority costume, so health/medical/financial advice in a fabricated AI answer requires legal review and the exchange is never presented as a real unprompted ChatGPT endorsement), and **Apple Notes reveals** (confession-not-conversation: note title as the hook, first-person list typed live with keyboard-taps-only audio, one typo-and-correction, the product as the least enthusiastic line, realizations grounded in real reviews per Grounded Inputs). SKILL.md pointer updated to the three-surface framing and adds 'ChatGPT ad' and 'Apple Notes ad' triggers. New eval (id 8) covers the health-claims compliance flag, surface selection, and Notes craft rules. Format source credit unchanged (Gooseworks iOS Ads pack). Closes #424.

### 2.8.4 (2026-07-09)

- **social** (2.1.0 → 2.2.0): added a **carousel framework library**. New `references/carousel-frameworks.md` — five slide-by-slide narrative architectures for Instagram carousels and LinkedIn document posts, re-expressed and extended from a pattern circulating on marketing X (Vibe Marketers HQ's five-framework breakdown): **Value-Stack** (exact-count cover → one item per slide → action close; the count is a checkable promise), **Problem-Proof** (result-as-fact hook → reframed problem → named mechanism → literal detail → screenshot receipt that closes slide 1's loop), **Hack List** (contrarian stat hook → why the common approach fails → one *named* technique per slide → thesis + CTA), **Rant Callout** (provocative claim → specific escalation → the fairness pivot that keeps it conviction-not-bitterness → signed close), and **Demo Walkthrough** (outcome first → pain → numbered process overview *before* the detail to cut mid-swipe drop-off → one real screenshot per step → result + positioning). Includes a framework-selection table (match structure to content type), two cross-framework rules (slide 1 is the thumbnail; one visual template per carousel), per-framework SaaS examples and failure modes, platform notes (IG 4:5 specs, LinkedIn PDF document posts with the post text as a second hook, TikTok photo-mode pacing), a production checklist (real claims only, exact counts delivered, one CTA), and measurement guidance (judge on saves + completion, not likes). SKILL.md wires the reference next to post templates and adds 'carousel,' 'slide-by-slide,' and 'document post' triggers; post-templates.md's generic Carousel Hook now points to the full library. New eval (id 7) covers framework selection, named-technique slides, LinkedIn document-post guidance, and no-invented-stats. Closes #421.

### 2.8.3 (2026-07-09)

- **ad-creative** (2.3.0 → 2.4.0): added a **brand-flexible style tier** to `references/motion-video-ads.md` — four token-driven styles that absorb any company's brand system instead of imposing their own palette: **monoline editorial** (thin single-weight ink line-art on the brand neutral, one accent sweep — the most universally brandable), **Swiss typographic** (the label set enormous in the brand's type on a grid; works for any brand with a font and a color), **wireglow** (wireframe subject on near-black with one gradient accent beam — dev-tool/dark-mode brands), and **duotone screenprint** (photography reduced to ink + accent). All driven by a **brand slots contract** — FIELD (neutral ground), INK (drawing/type color), ACCENT (one element per frame, scarcity is the design), TYPE FEEL, plus per-brand constraints (e.g. "gradients only on edges") — resolvable from brand guidelines or `.agents/product-marketing.md`. Includes per-style motion notes (lines draw themselves, beams pulse, type settles) under the same composition-never-changes rules. All four verified to render with clean typography using a real brand's tokens.

### 2.8.2 (2026-07-09)

- **ad-creative** (2.2.0 → 2.3.0): added the **faceless motion-style video ad format**. New `references/motion-video-ads.md` (format popularized by @borjafat; original re-expression of the open Bomx `super-video-maker` motion-collage recipe, extended with production lessons from shipping it end-to-end): a fully generated 15–45s concept/explainer video — styled poster stills (one per beat, series-locked via reference images) → image-to-video "living" motion → TTS narration → whisper-word-timed captions — at roughly $3–6 and ~15 minutes per finished video. Covers the provider-agnostic pipeline with a one-key Gemini path (Nano Banana Pro + Veo 3.1 + Gemini TTS) and alternatives (GPT-Image/Flux, Seedance/Kling/Runway, ElevenLabs), a **five-style visual library** with fill-in prompt formulas (screen-print collage, flat vector explainer, papercraft diorama, pop-art comic, claymation), a motion prompt formula, hard-earned QC gotchas (image-to-video models inject photoreal "maker hands" — and negative prompts make it worse; always QC each clip's final 2 seconds; caption/label collision; TTS/whisper sound-alike words in CTAs), ad-specific rules (brand in the poster for sound-off autoplay, beat 1 is the 3-second hook, regenerate stills per aspect rather than cropping), and AI-content disclosure notes. SKILL.md wires the reference into Generating Ad Visuals and adds 'motion video ad,' 'faceless video ad,' 'animated explainer ad,' and 'motion collage ad' description triggers.

### 2.8.1 (2026-07-08)

- **ad-creative** (2.1.0 → 2.2.0): added the **iMessage chat-reveal video ad format**. New `references/imessage-video-ads.md` — an original distillation of the format popularized by Shiv Sakhuja / Gooseworks (their public `create-imessage-video-ad` skill; the repo carries no open-source license, so content was re-expressed with credit rather than copied): a 9:16 video where a scripted iMessage thread unfolds bubble-by-bubble — screenshot hook → friend reacts → "what app is that?" → brand + promo-code reveal → static end card. Covers when to use it and when not (considered B2B, nothing screenshot-able, regulated-industry compliance), a compliance/grounding section tying dramatized conversations to the skill's Grounded Inputs rules (facts in the thread must be real; never frame the thread as a real testimonial), the six concept angles (result-as-screenshot, setup flex, cancellation moment, feature-as-punchline, friend-asks-friend inverse, receipt-as-hook), ad anatomy with script + pacing rules (8–14 bubbles, texting voice, brand appears once and late, rhythm not metronome, link-underlined promo code), three production routes (off-the-shelf Gooseworks skill; code-based HTML mockup + one continuous Playwright recording + ffmpeg stitch; Remotion for templated scale), the craft rules that sell the illusion (the recognizable send/receive SFX — CC0 recordings on BigSoundBank, with a trade-dress legal-review note; silent typing indicators; composer-typed text must equal sent text; static end card with the real logo SVG; native 1080×1920 recording; HTML-mimic real app UIs for hook screenshots instead of AI-generating them), a ship checklist, and an iteration order (hook attachment first). SKILL.md wires the reference into Generating Ad Visuals and adds 'iMessage ad,' 'chat reveal ad,' 'text message ad,' and 'fake DM ad' description triggers. Closes #411.

### 2.8.0 (2026-07-06)

- Added `marketing-council` skill — a simulated board of advisors staffed by twelve legendary marketers, built so their lenses deliberately collide: Seth Godin, David Ogilvy, Eugene Schwartz, Claude Hopkins, Gary Halbert, Russell Brunson, Alex Hormozi, April Dunford, Rory Sutherland, Byron Sharp, Ann Handley, and Gary Vaynerchuk. Three session modes (quick take / 3-5 seat council session / full council), a seating table mapping question types to strong fits plus **designated dissenters** (an agreeing council is an anti-pattern — e.g., Sharp dissents on niche strategies, Godin on funnel pressure, Hopkins on unmeasurable brand plays), and a session protocol ending in a **disagreement map** (each conflict named as its underlying trade-off plus the evidence that would settle it) and a chair's synthesis with skill handoffs. Per-advisor dossiers in `references/advisors/` were research-grounded via parallel web-research passes: each carries lens, frameworks with verified attributions (incl. misattribution flags — Dream 100 is Chet Holmes's, "salesmanship in print" is John E. Kennedy's coinage, brand image originated with Gardner & Levy, AIDA predates Halbert), documented positions with named sources, signature questions, best-for/blind-spots (with documented criticisms so dissent is honest), voice notes, and key works. Hard grounding rules: output labeled as simulation; no fabricated quotes (verifiable quotes with source, else paraphrase attributed to the work); no implied endorsements of the user's specific company; extra care for the eight living advisors including explicit do-not-fabricate flags (e.g., Hormozi launch figures are self-reported; recency questions about living advisors route to the research pass). Optional live research pass integrates deep-research / watch-video / last30days-style skills when installed, degrading to web search. `references/advisor-template.md` supports custom advisors saved to `.agents/advisors/` with a two-tier grounding standard (public figures need sources; private advisors' positions must come from the user, never invented). Includes an `evals/evals.json` suite covering dissent enforcement, quote discipline, custom-advisor flow, and the do-not-fabricate rule. Closes #391. Total skills: 47.

### 2.7.0 (2026-07-05)

- **ad-creative** (2.0.0 → 2.1.0): added scaled static ad production with grounded inputs. New `references/static-ad-templates.md` — a 15-template structural library for static ads (Headline Statement, Us vs. Them, Stat Callout, Review Card, Testimonial Stack, Before/After, Problem/Solution, Founder Message, Feature Spotlight, Press Mention, Lifestyle Hero, Numbered List, FAQ Card, Competitor Callout, Origin Story), each with structure, copy slot, DTC + SaaS examples, sourcing guidance, and compliance notes where relevant (before/after claims, press logos, comparative advertising). SKILL.md adds **Mode 3: Scaled Static Batches (Grounded)** and a **Grounded Inputs** section: a durable inputs corpus (`inputs/winning-ads/`, `inputs/reviews/`, `inputs/comments/`, plus `brand/`), hard grounding rules (every concept cites its source — a real review, winning ad, or ad comment; no invented claims or testimonials; refuse to generate when required inputs are empty rather than falling back to ungrounded output), and input-decay guidance. Ad comments called out as the most-skipped, highest-value input (public objections → FAQ Card ads; unprompted praise → customer-written angles). New static batch output format: `outputs/YYYY-MM-DD/` with scannable `INDEX.md` (template + grounding per concept), per-concept files, and images — built for the pick-5-of-50 human review workflow. Two new Common Mistakes (generating without grounding, skipping the comments input) and cross-refs to `marketing-loops` and `customer-research`. Frontmatter description adds 'static ads,' 'static ad concepts,' and 'ad templates' triggers. Remixed from a DTC "morning ads" playbook pattern, adapted for cross-agent use and extended with B2B/SaaS examples.
- **marketing-loops** (1.0.0 → 1.1.0): added **the daily-creative-drop loop** to the Paid section of `references/loop-catalog.md` (loop #44) — a daily batch of grounded static ad concepts via `ad-creative` Mode 3. Full nine-part anatomy: acts only when the grounded inputs corpus is populated (else asks for inputs instead of generating), one-batch-per-day idempotency via dated output folders plus near-duplicate tracking across recent batches, stages creative only (never publishes to the ad account), pauses itself if batches go unreviewed for a week (vanity-loop detection), and a companion input-freshness cadence (weekly `inputs/winning-ads/` refresh; monthly `inputs/reviews/` and `inputs/comments/` refresh).
- **ads** (2.1.0 → 2.2.0): major B2B operations expansion — five new references plus a routing-table pattern, adapted (re-expressed, reconciled, and extended with our own framing) from practitioner playbooks, notably Ivan Falco's ads-skills (ColdIQ; MIT + Commons Clause, so all content was rewritten rather than copied). New **Reference Routing** table at the top of SKILL.md maps user intent → reference file, with a hard rule that live-account operational decisions load the relevant playbook first. New references: **b2b-paid-playbook.md** (5-stage demand lifecycle past the funnel — Create/Capture/Accelerate-Activate/Revive/Expand with bottom-up build order; budget-by-stage matrix with ROI timelines; leading vs. lagging signals for 2-24-month sales cycles; breakeven CPL/CPC derivation; hard kill rules — 2-3× target CPL at zero conversions for new ads, 1.5-2× over target for aging ads; the optimize-to-quality trap + offline conversion loop with "the CRM wins" reconciliation; Urgency/Budget/Fit 0-9 lead scoring ranked by ad; the scaling quadrant 2×2; measurement maturity gate; channel selection incl. paid-review listings and the $100 test). **meta-decision-system.md** (fully quantified kill/graduate/scale engine anchored on TCPL — target cost per *qualified* lead: ad-count ceiling formula, 80/20 Scaling/Testing dual-CBO structure, day-7 delivery check with fair-share math, weekly quality evaluation with a 3×TCPL data gate and QL-rate bands, five-condition graduation criteria, fatigue frequency bands by campaign type, swap rules, creative production math with win rates and minimum proven-ad inventory, +20%-per-5-days scaling protocol with rollback triggers, weekly cadence, lead-form friction / social-amnesia fixes, Advantage+ transition at ~50 conversions/week, benchmarks + Q1/Q4 seasonality). **linkedin-b2b-playbook.md** (auto-then-manual-at-−20% bidding progression, penetration-based scaling triggers, audience sizing rules and failure modes, job-functions-vs-titles tradeoffs incl. the seniority mutual-exclusivity and Business-Development-contains-C-suite gotchas, audience splitting rules and platform distribution bias, funnel-stage benchmarks with the CTRTLP-vs-CTR trap, thought-leader-ads playbook incl. the 72-hour organic-first edit trick and format-as-auction-tactic insight, campaign-group build order, document/conversation/CTV format notes, the non-retroactive retargeting warning, and an audit shortlist). **google-search-playbook.md** (the five-rung intent ladder with don't-skip-rungs gating, brand pause test on total-not-paid conversions, capture-before-create channel rule, separate-budgets-by-intent account structure with themed-ad-groups-not-SKAGs and default settings to flip, Phrase/Exact→Broad progression with 30-conversion gates, starter negative lists + negative match-type mechanics gotcha, the weekly search-terms ritual with don't-over-negative restraint, bidding-by-conversion-volume table with ±10-15% target moves, the 2× daily budget rule, offline conversion import via GCLID, QS fix-order and form-length-as-intent-gate, PMax-for-B2B guardrails and value ranking, benchmarks + the 8-metric weekly scorecard). **abm-playbook.md** (go/no-go thresholds, LinkedIn ABM 1:1/1:few/1:many with list-size mechanics and segmentation against enterprise over-serving, personalized-creative lift + the Germany legal exception, engagement-based frequency capping, ABM-on-Meta enrichment workflow for the sub-5% match-rate problem, acceleration campaigns against open pipeline on awareness objectives, 60/30/10 cross-channel split, the UTM cross-channel remarketing mechanic, sales orchestration with 48-hour engagement triggers, and account-movement KPIs + 80/20 incrementality holdouts). Also: the mandatory **Google RSA Output Spec** moved verbatim from SKILL.md to `references/rsa-output-spec.md` (SKILL.md keeps a mandatory load-and-follow pointer), bringing SKILL.md from 552 back under the 500-line limit. New description triggers: 'ABM,' 'account-based marketing,' 'B2B ads,' 'lead quality,' 'negative keywords,' 'Performance Max,' 'thought leader ads,' 'when should I kill an ad.' New Related Skills cross-refs to `revops` and `customer-research`.

### 2.6.0 (2026-07-01)

- Added `marketing-loops` skill — a library of 43 repeatable marketing loops (recurring agent workflows an agent runs on a cadence). Inspired by ForwardFuture's Loop Library pattern but scoped to marketing operations, and positioned as the operational cousin of `marketing-ideas` (ideas = what to try once; loops = what to keep doing on a schedule). SKILL.md defines a nine-part loop anatomy — check cadence, acts-when (action condition), purpose, skills used, loop body, self-check, **state/idempotency** (last-run marker, dedupe key, cooldown — so loops don't double-act or re-nag), stop/bail-out, and output — plus a cadence rule (match frequency to how fast the signal actually changes), when NOT to loop (strategy/creative work, unreviewed spend/publish, sparse signals, vanity loops), and scheduling guidance that defers the mechanics to `loopify` (Claude Code `/loop` / `ScheduleWakeup` / `CronCreate`) or plain cron. `references/loop-catalog.md` holds all 43 loops grouped by function: SEO & Content (keyword-gap, ranking-drop watch, content-decay, internal-linking, programmatic-SEO quality, content-repurposing, content-calendar refill), Paid (ad-fatigue, paid-search query-mining, retargeting hygiene, landing-page regression), Earned/Social/Partnerships (newsjacking, social-listening, community-engagement, competitor-watch, backlink-prospecting, directory-submission, partner-pipeline), Activation (onboarding drop-off, signup-funnel-leak, lead-capture asset, feature-adoption), Retention (churn-signal, lifecycle-email-refresh, re-engagement, email-deliverability, voice-of-customer), Revenue (trial-conversion, PQL/upgrade-intent, pricing-page-experiment, paywall-optimization, expansion/upsell, failed-payment/dunning), Referral & Advocacy (referral-nudge, review-and-UGC-harvest, review-site-management, case-study-sourcing), and Ongoing Ops (weekly-marketing-review, experiment-backlog, analytics-anomaly, brand-mention/reputation, tracking-QA, campaign-postmortem). Each entry orchestrates existing skills and carries concrete guardrails — e.g. newsjacking has a veto list (tragedy/politics/crisis/sensitive verticals) + mandatory human approval; ad-fatigue requires real significance (spend/impressions/conversions/attribution/learning-phase); lifecycle-email optimizes on clicks/replies/complaints/bounces not opens; pricing/paywall judge winners on revenue-per-visitor/refunds/churn not conversion alone; review-harvest enforces consent/FTC/platform ToS; the experiment-backlog loop is a thin wrapper that hands off to `ab-testing`. `references/loop-template.md` gives authors a copy-paste template (fill-in prompts + worked before/after example + ship checklist) for creating their own loops. Three further references round out the skill: `loop-orchestration.md` (how loops compose into a four-layer system — sensing → diagnostic → action → learning — plus a staged rollout path so you adopt tracking + a weekly review before acquisition, and never build all 43 at once), `loop-state.md` (where loop state lives — `.agents/loops/<loop>.json` — the watermark/dedupe/cooldown/in-flight idempotency patterns, and a run-log format that doubles as a vanity-loop detector), and `loop-guardrails.md` (a two-tier action model of autonomous-safe vs. gated actions, spend/send caps + allowlists, CAN-SPAM/GDPR/FTC/platform-ToS compliance mapped to the loops each governs, PII handling, an always-escalate list, a required kill switch, and a pre-launch checklist). Includes a banned-vocabulary list (no "set it and forget it" / "fully autonomous marketing" / "10x on autopilot") and an `evals/evals.json` suite. Total skills: 46.
- **ads** (2.0.1 → 2.1.0): reframed the skill around the "audience knowledge → creative first, targeting filters second" shift, plus a new modern Meta playbook. Rewrote the **Audience Understanding & Targeting** section — audience research is still the highest-leverage work, but where you apply that knowledge has changed: as ad-platform algorithms have improved at matching, feeding audience identifiers into the *creative* (headlines, copy, hooks, examples) now outperforms jamming them into *targeting filters*. Added a platform-by-platform table splitting how much audience knowledge should go to creative vs. targeting (Meta post-Andromeda 80%+ creative; Google Search 60% targeting; PMax/Demand Gen 70% creative; LinkedIn 60% targeting; TikTok 70% creative; Twitter/X 50/50), guidance on applying each kind of audience identifier to creative, and a "trying to fix weak creative with hyper-precise targeting" failure-mode callout. Added a **Modern Meta playbook (Andromeda era — 2026+)** section covering Meta's 2025 Andromeda algorithm change: creative volume as the binding constraint (statics > polished video, ~1 hr/week of fresh creative for the winning offer), creative-as-targeting (broad audience + specific creative, with a duplicate-and-strip-targeting A/B test), and the 4-component retargeting framework (segment by funnel stage, retarget with different offers). Interest-stacking is now flagged as actively harmful on Meta. Skill body only; frontmatter description unchanged.

### 2.5.1 (2026-06-16)

- Bumped `copywriting`, `launch`, `pricing`, and `sales-enablement` from 2.0.0 → 2.0.1 to reflect the description changes that shipped in v2.5.0 (cross-references added pointing to the new `offers` skill). The skill bodies are unchanged; only the frontmatter description picked up a new "For ..., see offers" line. Without the version bump, the repo's update check (which compares VERSIONS.md against local skill metadata) would not surface the routing/discovery change to users with installed copies. Caught by codex review.

### 2.5.0 (2026-06-16)

- Added `offers` skill for offer design — the thing you actually sell, not the page that sells it. Built around two frameworks: (1) the Value Equation (Dream Outcome × Perceived Likelihood / Time Delay × Effort), originally Hormozi, now standard across direct-response and creator-economy training; and (2) the six-component anatomy of a complete offer (core deliverable, bonus stack, guarantee, scarcity, name, price + payment structure). Self-scoped explicitly: best for services, agency retainers, courses, coaching, info products, high-ticket B2B, and direct response. Less load-bearing for pure self-serve SaaS where `pricing` does more work. References include: `value-equation.md` (full breakdown of the four levers with diagnostic prompts and a worked example of a stuck $3K copywriting course), `offer-anatomy.md` (the six components with worked examples and a fractional-CMO before/after), `guarantee-design.md` (eight guarantee types with decision tree by business type, refund tolerance, and buyer sophistication; honest case for anti-guarantees on premium offers), `bonus-stacking.md` (bonuses-as-objection-handlers, the math of stated value, the 4-bonus pattern that works, common failure modes), `scarcity-urgency.md` (honest formats: capacity / cohort / founding-member / inventory / seasonal / bonus-expiry / price-increase; explicit rejection of fake countdown timers and manufactured FOMO; why fake scarcity is uniquely costly), `offer-formats.md` (default offer format by business type — service, course, coaching, info product, high-ticket B2B, agency retainer, self-serve SaaS, direct-response — with what to watch for each), and `examples.md` (six anonymized before/after worked examples spanning fractional CMO, copywriting course, Notion templates, B2B SaaS annual contract, group coaching mastermind, content agency retainer). Includes a banned-vocabulary list (game-changing, revolutionary, 10x, secret, hidden, "limited time" with no actual limit) and explicit anti-patterns (manipulative scarcity, over-promising guarantees, bonus inflation, course-bro aesthetic).
- Cross-references added in `pricing`, `copywriting`, `launch`, and `sales-enablement` descriptions pointing to `offers` for offer construction.
- Total skills: 45.

### 2.4.2 (2026-06-15)

- **ai-seo** (2.0.1 → 2.1.0): added coverage of Google's Open Knowledge Format (OKF), a v0.1 markdown spec for agent-readable site bundles introduced on the Google Cloud blog on 2026-06-12 and shipped inside Knowledge Catalog. New `references/okf.md` reference covers what OKF is (directory of cross-linked markdown files with YAML frontmatter — `type` required, plus `title`/`description`/`resource`/`tags`/`timestamp` recommended), honest framing (Google built it for data-team catalog metadata; site-readable repurposing popularized by Suganthan Mohanadasan is a clever secondary use), what it does for AI search today (nothing immediate; protocol-layer registration like early schema.org adoption), where OKF fits in the agent-readable stack alongside `sitemap.xml` / `robots.txt` / `llms.txt` / `/pricing.md` / schema, three ways to ship a bundle (Suganthan's free web generator, his pending WordPress plugin, or by hand), hosting guidance (`yoursite.com/okf/index.md` plus an `llms.txt` line pointing to it), when to skip (closed platforms like Wix/Squarespace, very small sites, sites without other machine-readable files), and what to watch (v1.0 spec, AI engine adoption signals). `SKILL.md` adds a brief OKF subsection under "Machine-Readable Files for AI Agents" pointing to the reference. Frontmatter description extended with new triggers: `llms.txt`, `OKF`, `Open Knowledge Format`, `knowledge bundle`, `agent-readable site`. `references/platform-ranking-factors.md` Google AI Overviews section gets an OKF callout framing it as a "register early" protocol bet rather than a confirmed ranking signal.

### 2.4.1 (2026-06-10)

- Renamed `pr` skill to `public-relations` to avoid collision with pull-request skills in other Claude Code plugins (common naming for code-review / GitHub PR automation). The skill description already disambiguated from pull requests, but the directory name `pr` was still ambiguous to skill resolvers and to users typing `/pr`. The rename happened within hours of the initial v2.4.0 publish, before meaningful install adoption. No content changes; skill version stays at 1.0.0. All cross-references in `social/SKILL.md`, `VERSIONS.md`, and `README.md` updated accordingly.

### 2.4.0 (2026-06-10)

- Added `public-relations` skill (originally shipped as `pr`, renamed in v2.4.1) for public relations / earned media work — pitching journalists, newsjacking trending stories, responding to press requests (HARO/Connectively, Qwoted, Featured, Help A B2B Writer), and building the owned-media foundation (press page + media kit). Four PR modes (reactive / proactive / inbound / owned), explicit when-to-skip framing, and a banned-vocabulary list. References include: `newsjacking.md` (detect → score → angle → pitch loop with newsworthiness scoring rubric, 7 angle templates, Google News / HN / Reddit curl recipes, failure modes); `journalist-pitching.md` (media list construction, journalist fit scoring, 6 pitch templates by angle — data story / exclusive launch / op-ed / customer story / trend connector / newsjack response — subject-line craft, embargo etiquette, follow-up cadence); `press-platforms.md` (daily triage workflow, response template, ROI reality check); `media-outlets.md` (tiered list of tech press, SaaS, AI, devtools, business outlets, newsletters, podcasts, vertical press, regional press — explicitly scoped to journalist-driven outlets, with startup directories deferred to `directory-submissions`). Scope is enforced via cross-references: the `public-relations` skill handles earned media; `directory-submissions` handles Product Hunt / BetaList / SaaS directories; `launch` handles the broader launch moment.
- **social** (2.0.0 → 2.1.0): added `references/listening.md` for engagement triage — a daily loop for surfacing the top posts to comment on rather than scrolling feeds. Includes a 5-dimension scoring rubric (ICP fit, intent signal, reach potential, comment opportunity, recency), comment quality tiers, curl-based recipes for Reddit / HN Algolia / Bluesky (no auth required), and a browser-driven workflow for LinkedIn and X via `dev-browser` with persistent session. Added `references/listening-sources-template.md` — a copyable starter for `.agents/listening-sources.md` covering brand/category context, ICP definition, target accounts per platform, intent keywords, subreddits, saved-search URLs, and a do-not-engage list. SKILL.md Engagement Strategy section now links to the listening reference.
- Total skills: 44.

### 2.3.0 (2026-05-27)

- Added `marketing-plan` skill — comprehensive AARRR-structured marketing plan generator. Produces a 13-section Notion-paste-ready plan document (executive summary, strategic frame, current state, AARRR breakdown, 90-day roadmap, 12-month outlook with funding-stage capability unlocks, marketing operations stack mapping skills + MCPs to AARRR stages, tactical idea bank cross-referencing all 139 `marketing-ideas` to AARRR + client-specific status, measurement framework, RACI, open decisions). Customized for current budget, team, stage, and tooling stack. Three-phase workflow: INIT (research + intake), REVIEW (section-by-section walkthrough), FINALIZE (compile + verify + optional publish to shared repo). References include methodology, plan-template, aarrr-framework, current-state-rubric (self-contained 17-section scoring rubric), ops-stack-mapping, idea-cross-reference (139-idea AARRR mapping), funding-stage-unlocks, measurement-framework, client-types (variations by B2B SaaS / D2C / hardware-hybrid / marketplace / dev tool / clinical / commerce), example-quietude (anonymized canonical reference plan, based on a real fCMO engagement with names/identifying details changed), budget-planning (two scientific methods for setting the marketing budget — Revenue-Based 5–40% of ARR, and Goal-Based formula reverse-engineered from the revenue target; plus blended CAC calculation, the 10–20% experimental buffer rule, the 3-3-2-2-2 VC growth path, and the forecasting reality check), growth-patterns (the real shape of SaaS growth — $0–10K / $10K–100K / $100K–1M phases with binding constraints, linear vs step-function vs S-curve patterns, and Channel × Product × Market layering), and team-and-agency-model (the strategy-in-house / execution-outsourced principle, three core functions Growth/Product/Content, π-shaped marketer framework, title progression Manager → Lead → Director → VP → Chief, agency selection framework, and the three-stage scaling model Early/Growth/Scale). Budget, growth-pattern, and team frameworks drawn from *Founding Marketing* by Corey Haines.
- Total skills: 43.

### 2.2.0 (2026-05-26)

- Added `prospecting` skill for building qualified prospect lists across SaaS, B2B, and local SMB motions. Includes shared 5-phase framework (ICP → discovery → qualify → score → output) plus branch-specific references (saas-prospecting, b2b-prospecting, local-prospecting), data-sources guide covering Apollo / Clay / ZoomInfo / Clearbit / Hunter / Snov / Truelist / RB2B / Sales Nav / BuiltWith / Crunchbase / GitHub, and compliance reference (CAN-SPAM, GDPR, CASL, platform ToS).
- Added `tools/clis/github-prospects.js` CLI for pulling GitHub stargazers, forkers, and watchers as a developer-intent signal — with pagination, enrichment, filter-based early termination, and CSV output.
- Added new tool integration docs: `truelist` (email deliverability validation, OpenAPI-aligned), `github` (REST API for prospecting), `firecrawl` (single-target page scraping), `browserbase` (real Chromium for JS-heavy pages or interaction).
- **ads** (2.0.0 → 2.0.1): added Google RSA Output Spec section enforcing 15 headlines × 30 chars, 4 descriptions × 90 chars, ad group structure labels, ≥8 negative keywords, ≥4 sitelinks/callouts, output ordering to avoid truncation, and a self-check before responding. Includes optional Brazilian medical (CFM) compliance rules when product context indicates that vertical.
- Added `sequenzy` tool integration (email marketing platform with MCP support).
- Fixed plugin.json version drift (was stuck at 1.9.0 across three releases) — `sync-skills.js` now auto-syncs `plugin.json` version to `marketplace.json` on every change. Closes #323.
- Added skill install artifacts (`.agents/`, `.claude/`, `skills-lock.json`) to `.gitignore`.
- Total skills: 42.

### 2.1.0 (2026-05-21)
- Added `sms` skill for SMS/MMS marketing — welcome flows, abandoned cart, post-purchase, win-back, promotional sends, and transactional/auth. Includes compliance reference (TCPA, A2P 10DLC, GDPR, CASL), sequence templates with character counts, and platform comparison (Klaviyo, Postscript, Attentive, Twilio, Brevo, SimpleTexting, Customer.io).
- Total skills: 41

### 2.0.1 (2026-05-18)

Content patch — no breaking changes, no new skills.

- **ai-seo** (2.0.0 → 2.0.1): aligned with Google's official AI features optimization guide. Added sections for Google's stance on AI optimization, query fan-out, agentic experiences (including UCP), explicit "what NOT to do" (scaled content abuse, etc.), and Search Console expectations. Reframed llms.txt / pricing.md / schema markup recommendations as "Google says not required, helpful for non-Google AI engines." Moved content-type tactics to `references/content-types.md` (added local/ecom Merchant Center + Business Profile guidance per Google).
- **image** (2.0.0 → 2.0.1): refreshed model lineup to current May 2026 releases — Nano Banana / Nano Banana Pro family naming, Flux Pro 1.1 + Kontext + Dev + Schnell variants, Ideogram 3.0, ChatGPT Images 2.0 / GPT Image, Midjourney v7, Recraft V3, SD 3.5 / SDXL. Updated decision tree and trigger phrases.
- **video** (2.0.0 → 2.0.1): refreshed model lineup — Sora 2 promoted from limited-availability caveat, Kling 2.5/3.0, added Seedance (ByteDance), Hailuo / MiniMax (character consistency), Hunyuan Video / Wan 2 (open-weight self-hosted), Pika 2.x. New "Quick picks" guide.

Total skills: 40 (unchanged).

### 2.0.0 (2026-05-05)

**Breaking changes** — Users must reinstall skills after this update.

#### Skill Renames (17)
| Old Name | New Name |
|----------|----------|
| ab-test-setup | ab-testing |
| analytics-tracking | analytics |
| aso-audit | aso |
| competitor-alternatives | competitors |
| email-sequence | emails |
| free-tool-strategy | free-tools |
| launch-strategy | launch |
| onboarding-cro | onboarding |
| paid-ads | ads |
| paywall-upgrade-cro | paywalls |
| popup-cro | popups |
| pricing-strategy | pricing |
| product-marketing-context | product-marketing |
| referral-program | referrals |
| schema-markup | schema |
| signup-flow-cro | signup |
| social-content | social |

#### Consolidations (1)
- `page-cro` + `form-cro` → `cro` (form content moved to `references/form.md`)

#### Why 2.0?
- Shorter, cleaner skill names
- Consistent naming conventions (no more `-strategy`, `-setup`, `-cro` suffixes)
- Consolidated CRO into single skill with references
- All cross-references updated across 100+ files

**Total skills: 40**

### 1.10.0 (2026-05-04)
- Added `co-marketing` skill for partner identification, joint campaigns, and co-marketing strategy
- Total skills: 41

### 2026-04-24
- Added `image` skill for AI image generation, design tools, profile/listing banners, and optimization
- Added `video` skill for AI video production (Hyperframes, HeyGen, Veo, Runway, Kling)
- Added short-form video section to `social` (1.3.0) — TikTok, Reels, Shorts frameworks
- Added HeyGen and Hyperframes tool integration guides
- Fixed plugin marketplace: `source` field now passes Claude Code schema validation (#270)
- Added proper `plugin.json` manifest with `"skills": "./skills"`
- Total skills: 40

### 2026-04-21
- Added `directory-submissions` skill for Product Hunt, G2, AI directories, and backlink strategy
- Added `competitor-profiling` skill for competitive intelligence research
- Added international SEO & localization section to `seo-audit` (1.2.0)
- Added conversion tracking reference to `ads` (cross-platform pixel setup)
- Added Zapier SDK integration for 8,000+ app access
- Fixed plugin loading: removed `./` prefix from marketplace.json skill paths (#243)
- Hardened CLI tools: Supermetrics API key moved to header, ZoomInfo JWT masked by default
- Fixed community-marketing YAML frontmatter (#240)
- Fixed Zapier webhook URL validation (#247)
- Added missing skills to VERSIONS.md (aso, community-marketing, customer-research — shipped in prior releases)
- Total skills: 38

### 2026-03-14
- Added `lead-magnets` skill for lead magnet strategy, format selection, and conversion optimization
- Added Composio integration layer for MCP access to OAuth-heavy tools (HubSpot, Salesforce, Meta Ads, LinkedIn Ads, Google Sheets, Slack, Notion, etc.)
- Added headless CMS integration guides (Sanity, Contentful, Strapi) with headless-cms reference
- Added 197 evals across all 33 skills for automated quality testing
- Optimized all 32 skill descriptions for better trigger phrase matching
- Replaced rigid imperatives with reasoning-based guidance across all skills
- Added 10 new CLI tools (airops, clay, close, coupler, crossbeam, outreach, pendo, similarweb, supermetrics, zoominfo)
- Added 13 new integration guides
- Bumped all 32 existing skills from 1.1.0 → 1.2.0

### 2026-02-27
- Migrated context path from `.claude/` to `.agents/` for agent-agnostic compatibility
- All skills now check `.agents/product-marketing.md` first, with `.claude/` fallback for older setups
- Updated install paths in README to reference `.agents/skills/`
- Bumped all 32 skills from 1.0.0 → 1.1.0

### 2026-02-22
- Added `revops` skill for revenue operations, lead lifecycle, scoring, routing, pipeline management, and CRM automation
- Added `sales-enablement` skill for sales decks, one-pagers, objection handling, demo scripts, and sales playbooks

### 2026-02-21
- Added `site-architecture` skill for website structure planning, page hierarchy, navigation design, URL structure, and internal linking strategy

### 2026-02-18
- Added `ai-seo` skill for AI search optimization (AEO, GEO, LLMO, AI Overviews)
- Moved AEO/GEO content patterns from `seo-audit` references to `ai-seo` skill
- Added `churn-prevention` skill for cancel flows, save offers, dunning, and payment recovery

### 2026-02-17
- Added `ad-creative` skill for bulk ad creative generation and performance-based iteration
- Added 51 zero-dependency CLI tools for marketing platforms (`tools/clis/`)
- Added 31 new integration guides (`tools/integrations/`)
- Added 4 email outreach CLIs: hunter, snov, lemlist, instantly
- Security hardening: header auth for meta-ads, URL encoding, input validation
- All CLIs reviewed via independent codex audit (auth, security, error handling, consistency)

### 2026-01-27
- Initial version tracking added
- Added tools registry with 29 integration guides
